# Virtual Walk GPS POC

React Native GPS-tracking proof of concept for the Virtual Walk / Virtual
Activity project. It validates the full GPS chain: continuous sampling →
point classification (accepted / pending / rejected) → validated mileage →
live Google Maps track → background tracking → local persistence & restart
recovery.

**This is a POC, not a production app.** No backend, no auth, no business
rules. All data stays on the device.

---

## Tech stack

| Layer | Choice |
|---|---|
| Runtime | React Native `0.85.3` (new architecture), React 19.2.3, Hermes |
| Language | TypeScript 5.8 (strict) |
| Package manager | Yarn 3.6.1 (node-modules linker, via corepack) |
| Navigation | React Navigation 7 (native-stack) |
| State | Redux Toolkit 2 + redux-persist (AsyncStorage) |
| Location | react-native-geolocation-service 5.3.1 |
| Maps | react-native-maps 1.27.2, **Google provider** |
| Distance | haversine |
| Android background | @voximplant/react-native-foreground-service 3.0.2 |
| Tests | Jest + @react-native/jest-preset |

## Prerequisites

- Node.js ≥ 22.11
- Yarn 3.6.1 (`corepack enable && corepack prepare yarn@3.6.1 --activate`)
- JDK 17
- Android SDK with platform 36 + build-tools 36 (auto-downloaded on first build)
- (iOS only) Xcode 16+, CocoaPods via `bundle exec pod install`

## Setup

```bash
COREPACK_ENABLE_DOWNLOAD_PROMPT=0 corepack yarn install
# postinstall runs patch-package automatically (fixes the foreground-service
# library's hard-coded compileSdk 28 — see patches/).
```

### Google Maps API key (optional)

Without a key the app still runs — the map area shows a clear
"key not configured" notice instead of crashing.

- **Android**: copy `android/app/googleMapsKey.properties.example` →
  `android/app/googleMapsKey.properties`, fill in your key. Git-ignored.
- **JS/iOS runtime**: edit `src/features/tracking/config/mapsKeys.local.ts`
  (git-ignored). iOS additionally reads `GOOGLE_MAPS_API_KEY` from Info.plist.

Never commit a real key. `.env.example` contains placeholders only.

## Run

```bash
# Metro + debug build (device attached or emulator running)
COREPACK_ENABLE_DOWNLOAD_PROMPT=0 corepack yarn android

# Build a debug APK for manual installation
COREPACK_ENABLE_DOWNLOAD_PROMPT=0 corepack yarn build:apk
# → android/app/build/outputs/apk/debug/app-debug.apk
# Install: adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

> Debug APKs load JS from Metro. For a standalone APK that runs without a
> dev server: `cd android && ./gradlew assembleRelease` (debug-signed in this
> POC) — or start Metro first with `yarn start`.

## Verify

```bash
corepack yarn typecheck   # tsc --noEmit
corepack yarn lint        # eslint
corepack yarn test        # jest (41 tests)
```

## App structure

```
Tracking screen   map + marker + segmented polyline + distance/time/signal +
                  Start/Pause/Resume/Stop + follow toggle + sampling picker
Diagnostics       point counts, rejection reasons, accuracy mean/P95, actual
                  callback interval, GPS gaps, raw vs validated distance,
                  app-state timeline, local JSON export
Session history   completed sessions (read-only replay + summary)
Settings          all filter thresholds + business-decision switches
```

## GPS pipeline (key files)

| Concern | File |
|---|---|
| Sampling profiles (high/balanced/battery) | `src/features/tracking/config/samplingConfigs.ts` |
| All filter thresholds | `src/features/tracking/config/filterConfig.ts` |
| watchPosition wrapper | `src/features/tracking/services/geolocationService.ts` |
| accepted/pending/rejected pipeline | `src/features/tracking/services/pointValidator.ts` |
| haversine distance + implied speed | `src/features/tracking/services/distanceCalculator.ts` |
| Session state machine | `src/features/tracking/store/trackingSlice.ts` |
| Orchestration + Android foreground service | `src/features/tracking/services/trackingEngine.ts` |
| Throttled incremental persistence + restore | `src/features/tracking/services/sessionPersistence.ts` |
| Display-track simplification (never touches mileage) | `src/features/tracking/utils/trackSimplification.ts` |

Filtering summary (defaults, all configurable in Settings):

- accuracy ≤ 25 m → candidate for acceptance; 25–50 m → pending buffer;
  > 50 m → rejected (kept in raw only)
- invalid / stale / duplicate timestamps → rejected
- impossible jump (> 180 km/h implied over ≥ 50 m) → segment rejected
- GPS gap > 30 s → session stays active, distance paused; first trusted fix
  after the gap becomes a new anchor and is **not** bridged
- Pause / Resume / restart recovery never bridge the displacement
- excessive speed (20 km/h default) → flagged, segment rejected only; session
  continues; switchable off

## Platform notes & known limitations (IMPORTANT)

- **Android**: foreground service (location type) + notification keeps
  `watchPosition` alive in background/lockscreen on most OEMs. Aggressive
  battery managers (Xiaomi/Huawei/Oppo…) may still kill it — whitelist the
  app in battery settings when testing.
- **iOS**: `UIBackgroundModes: location` configured. Background updates
  continue while the app holds a live location subscription; after the app is
  force-quit, NO location continues (Apple restriction) — restart recovery
  only restores *data*, not tracking.
- **App killed by swipe-away / OS**: tracking stops on both platforms. The
  POC verifies *data recovery* after restart, not continuous tracking after
  termination. Nothing here claims otherwise.
- Old-architecture native modules run through the RN 0.85 interop layer;
  verified to compile and bundle, runtime behaviour on real devices is part
  of the device test plan (docs/DEVICE_TEST_MATRIX.md).
- The `interval` you configure is a target only. The Diagnostics screen
  measures the *actual* callback interval (mean/P95).

## Docs

- `docs/TEST_PLAN.md` — how to run the device experiments
- `docs/DEVICE_TEST_MATRIX.md` — scenarios × platforms checklist
- `docs/RESULTS_TEMPLATE.md` — fill-in table per session
- `docs/TECHNICAL_FINDINGS.md` — what the POC proves / does not prove, and
  recommendations for the production decision

## Scope guardrails

No backend, no auth, no encryption, no Strapi, no production anti-cheat, no
Google Routes API. Optional local mock server (127.0.0.1 only) is *not*
implemented because the GPS flow never required it; the app is fully
functional without any server.
