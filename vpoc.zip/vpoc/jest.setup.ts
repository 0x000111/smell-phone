/**
 * Jest setup: mock native modules so pure logic can be unit-tested.
 * All coordinates used in tests are SYNTHETIC TEST DATA.
 */

jest.mock('react-native-geolocation-service', () => ({
  requestAuthorization: jest.fn().mockResolvedValue('granted'),
  watchPosition: jest.fn().mockReturnValue(1),
  clearWatch: jest.fn(),
  stopObserving: jest.fn(),
  getCurrentPosition: jest.fn(),
  PositionError: {
    PERMISSION_DENIED: 1,
    POSITION_UNAVAILABLE: 2,
    TIMEOUT: 3,
    PLAY_SERVICE_NOT_AVAILABLE: 4,
    SETTINGS_NOT_SATISFIED: 5,
    INTERNAL_ERROR: -1,
  },
}));

jest.mock('@voximplant/react-native-foreground-service', () => ({
  default: {
    createNotificationChannel: jest.fn().mockResolvedValue(undefined),
    startService: jest.fn().mockResolvedValue(undefined),
    stopService: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('react-native-maps', () => {
  const React = require('react');
  const noop = (name: string) => (props: Record<string, unknown>) =>
    React.createElement(name, props);
  return {
    __esModule: true,
    default: noop('MapView'),
    Marker: noop('Marker'),
    Polyline: noop('Polyline'),
    PROVIDER_GOOGLE: 'google',
  };
});

jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
);
