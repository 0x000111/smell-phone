/**
 * Minimal ambient declarations for native modules that ship without types.
 */

declare module '@voximplant/react-native-foreground-service' {
  interface NotificationChannelConfig {
    id: string;
    name: string;
    description?: string;
    importance?: number;
  }
  interface NotificationConfig {
    channelId: string;
    id: number;
    title: string;
    text: string;
    icon: string;
    priority?: number;
    button?: string;
  }
  class VIForegroundService {
    createNotificationChannel(config: NotificationChannelConfig): Promise<void>;
    startService(config: NotificationConfig): Promise<void>;
    stopService(): Promise<void>;
    on(event: string, handler: (...args: unknown[]) => void): void;
    removeListener(event: string, handler: (...args: unknown[]) => void): void;
  }
  const service: VIForegroundService;
  export default service;
}

declare module 'haversine' {
  interface HaversineOptions {
    unit?: 'km' | 'mile' | 'meter' | 'nmi';
    format?: '[lat,lon]' | '[lon,lat]' | '{lon,lat}' | '{lat,lng}' | 'geojson';
    threshold?: number;
  }
  /** Default format passes {latitude, longitude} straight through. */
  interface Coordinate {
    latitude: number;
    longitude: number;
  }
  function haversine(a: Coordinate, b: Coordinate, options?: HaversineOptions): number;
  export default haversine;
}
