import type { RawGpsPoint, ValidatedPoint } from './gps';
import type { SamplingConfigId } from '../config/samplingConfigs';

/** Session state machine (requirement 7). */
export type TrackingSessionState =
  | 'idle'
  | 'starting'
  | 'active_good_signal'
  | 'active_weak_signal'
  | 'paused'
  | 'resuming'
  | 'ending'
  | 'completed'
  | 'interrupted'
  | 'error';

export type GpsSignalLevel = 'good' | 'weak' | 'none' | 'unknown';

export interface PauseInterval {
  startedAt: number;
  endedAt: number | null;
}

export interface SessionEvent {
  at: number;
  type:
    | 'start'
    | 'pause'
    | 'resume'
    | 'stop'
    | 'state'
    | 'gps_gap'
    | 'gps_recovered'
    | 'app_state'
    | 'error'
    | 'persist'
    | 'restore';
  detail?: string;
}

/**
 * Everything persisted for a session (requirement 8). Persisted incrementally,
 * throttled — not on every single GPS callback.
 */
export interface TrackingSession {
  id: string;
  state: TrackingSessionState;
  samplingConfigId: SamplingConfigId;
  createdAt: number;
  startedAt: number | null;
  endedAt: number | null;

  /** Accumulated active (non-paused) duration in ms. */
  accumulatedActiveDurationMs: number;
  /** Timestamp when active timing last (re)started; null while paused. */
  activeSince: number | null;
  pauseHistory: PauseInterval[];

  rawPoints: RawGpsPoint[];
  validatedPoints: ValidatedPoint[];
  /** Index into validatedPoints where the last segment boundary occurred. */
  segmentBoundaries: number[];

  /** Sum of accepted segments only. */
  validatedDistanceM: number;
  /** Sum over all raw consecutive points (diagnostic only). */
  rawDistanceM: number;

  lastAcceptedPoint: RawGpsPoint | null;
  /** Timestamp of last accepted point; used for gap detection. */
  lastAcceptedAt: number | null;

  signalLevel: GpsSignalLevel;
  lastFixAt: number | null;
  /** Human-readable hint when the location provider reports an error. */
  lastError: string | null;

  events: SessionEvent[];
  /** Timestamp of last persistence write. */
  lastPersistedAt: number | null;

  /** Diagnostics counters (requirement 13.1). */
  stats: SessionStats;
}

export interface SessionStats {
  rawCount: number;
  acceptedCount: number;
  pendingCount: number;
  rejectedCount: number;
  rejectionReasons: Record<string, number>;
  gpsGapCount: number;
  longestGapMs: number;
  acceptedSegments: number;
  rejectedSegments: number;
  excessiveSpeedSegments: number;
  /** Callback intervals (ms) between consecutive raw points. */
  callbackIntervalsMs: number[];
  /** Accuracies (m) of accepted points. */
  acceptedAccuracies: number[];
  /** Count of points received per app state. */
  pointsByAppState: Record<string, number>;
}

export function createEmptyStats(): SessionStats {
  return {
    rawCount: 0,
    acceptedCount: 0,
    pendingCount: 0,
    rejectedCount: 0,
    rejectionReasons: {},
    gpsGapCount: 0,
    longestGapMs: 0,
    acceptedSegments: 0,
    rejectedSegments: 0,
    excessiveSpeedSegments: 0,
    callbackIntervalsMs: [],
    acceptedAccuracies: [],
    pointsByAppState: {},
  };
}

export interface CompletedSessionSummary {
  id: string;
  startedAt: number;
  endedAt: number;
  state: TrackingSessionState;
  samplingConfigId: SamplingConfigId;
  activeDurationMs: number;
  pauseDurationMs: number;
  rawDistanceM: number;
  validatedDistanceM: number;
  acceptedCount: number;
  rejectedCount: number;
  /** Full session kept for read-only map/diagnostics replay. */
  session: TrackingSession;
}
