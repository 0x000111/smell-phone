/**
 * Core GPS data types for the tracking POC.
 *
 * NOTE: Coordinates produced by tests are synthetic test data and must be
 * labelled as such in the test files. Real device coordinates are only ever
 * produced at runtime from react-native-geolocation-service.
 */

export type AppStateLabel = 'active' | 'background' | 'inactive' | 'unknown';

/**
 * A raw point exactly as returned by the device. Never modified by filtering
 * logic — kept only for diagnostics. See requirement 5.4.
 */
export interface RawGpsPoint {
  id: string;
  latitude: number;
  longitude: number;
  /** Device-reported fix timestamp (ms epoch). */
  timestamp: number;
  accuracy: number | null;
  altitude: number | null;
  altitudeAccuracy: number | null;
  /** Device-reported speed in m/s (may be null on some platforms). */
  speed: number | null;
  heading: number | null;
  appState: AppStateLabel;
  /** Wall-clock time the JS layer received the callback (ms epoch). */
  receivedAt: number;
  /** Optional provider hint from the library (Android). */
  provider?: 'fused' | 'gps' | 'network' | 'passive';
  /** Whether the OS flagged this fix as mocked. */
  mocked?: boolean;
}

export type PointDecision = 'accepted' | 'pending' | 'rejected';

export type RejectionReason =
  | 'invalid_coordinate'
  | 'stale_timestamp'
  | 'duplicate_timestamp'
  | 'poor_accuracy'
  | 'impossible_jump'
  | 'excessive_speed'
  | 'gps_gap_anchor'
  | 'micro_movement'
  | 'paused'
  | 'unknown';

/**
 * A point that has passed through the validation pipeline. Carries the
 * decision and, when rejected, the reason — so we can always answer
 * "why was this point accepted or rejected?" (requirement 5.4).
 */
export interface ValidatedPoint {
  raw: RawGpsPoint;
  decision: PointDecision;
  reason: RejectionReason | null;
  /** Distance in metres from the previous accepted anchor (if accepted). */
  segmentDistance?: number;
  /** Implied speed m/s between previous accepted anchor and this point. */
  impliedSpeed?: number;
}

/** A point kept in the pending buffer awaiting confirmation by later points. */
export interface PendingPoint {
  raw: RawGpsPoint;
  /** Accuracy band that caused it to be parked as pending. */
  reason: RejectionReason;
}

/**
 * A display point is what the map draws. It is derived from validated points
 * but may be simplified without ever affecting validated distance
 * (requirement 5.3 / 10.7).
 */
export interface DisplayPoint {
  latitude: number;
  longitude: number;
  /** Segment index so we never draw a line across a GPS gap / pause. */
  segment: number;
  kind: 'accepted' | 'pending' | 'rejected' | 'raw';
}
