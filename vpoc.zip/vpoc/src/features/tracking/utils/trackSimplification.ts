/**
 * Display-track helpers (requirements 5.3, 10).
 *
 * displayPoints are derived from validated points and MAY be simplified for
 * rendering performance — but this must never feed back into validated
 * distance. Simplification here is purely for the Polyline.
 */
import type { DisplayPoint, ValidatedPoint } from '../types/gps';

/**
 * Assign each validated point to a segment. A new segment starts at every
 * segment boundary index (gap / pause / resume) so the map never draws a line
 * across a gap (requirement 10.2).
 */
export function toDisplayPoints(
  validatedPoints: ValidatedPoint[],
  segmentBoundaries: number[],
): DisplayPoint[] {
  const boundarySet = new Set(segmentBoundaries);
  const out: DisplayPoint[] = [];
  let segment = 0;
  for (let i = 0; i < validatedPoints.length; i++) {
    const vp = validatedPoints[i];
    if (boundarySet.has(i) && i !== 0) {
      segment += 1;
    }
    if (vp.decision === 'accepted') {
      out.push({
        latitude: vp.raw.latitude,
        longitude: vp.raw.longitude,
        segment,
        kind: 'accepted',
      });
    }
  }
  return out;
}

/** Group a flat display list into per-segment coordinate arrays. */
export function groupBySegment(points: DisplayPoint[]): Array<Array<{ latitude: number; longitude: number }>> {
  const groups: Array<Array<{ latitude: number; longitude: number }>> = [];
  for (const p of points) {
    let g = groups[p.segment];
    if (!g) {
      g = [];
      groups[p.segment] = g;
    }
    g.push({ latitude: p.latitude, longitude: p.longitude });
  }
  return groups.filter(Boolean);
}

/**
 * Douglas–Peucker simplification for rendering only. Keeps endpoints and
 * points far from the simplified line. Validated distance is untouched.
 */
export function simplifyForDisplay(
  points: Array<{ latitude: number; longitude: number }>,
  epsilonDeg: number,
): Array<{ latitude: number; longitude: number }> {
  if (points.length < 3) return points;
  const keep = new Array<boolean>(points.length).fill(false);
  keep[0] = true;
  keep[points.length - 1] = true;
  dpRecursive(points, 0, points.length - 1, epsilonDeg, keep);
  return points.filter((_, i) => keep[i]);
}

function dpRecursive(
  points: Array<{ latitude: number; longitude: number }>,
  first: number,
  last: number,
  epsilon: number,
  keep: boolean[],
): void {
  if (last <= first + 1) return;
  let maxDist = -1;
  let index = -1;
  const a = points[first];
  const b = points[last];
  for (let i = first + 1; i < last; i++) {
    const d = perpendicularDistance(points[i], a, b);
    if (d > maxDist) {
      maxDist = d;
      index = i;
    }
  }
  if (maxDist > epsilon && index !== -1) {
    keep[index] = true;
    dpRecursive(points, first, index, epsilon, keep);
    dpRecursive(points, index, last, epsilon, keep);
  }
}

function perpendicularDistance(
  p: { latitude: number; longitude: number },
  a: { latitude: number; longitude: number },
  b: { latitude: number; longitude: number },
): number {
  const dx = b.longitude - a.longitude;
  const dy = b.latitude - a.latitude;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) {
    return Math.hypot(p.longitude - a.longitude, p.latitude - a.latitude);
  }
  const t = Math.max(
    0,
    Math.min(1, ((p.longitude - a.longitude) * dx + (p.latitude - a.latitude) * dy) / lenSq),
  );
  const projX = a.longitude + t * dx;
  const projY = a.latitude + t * dy;
  return Math.hypot(p.longitude - projX, p.latitude - projY);
}

/** Debug overlay helpers: pending + rejected + raw points. */
export function debugDisplayPoints(validatedPoints: ValidatedPoint[]): {
  pending: DisplayPoint[];
  rejected: DisplayPoint[];
} {
  const pending: DisplayPoint[] = [];
  const rejected: DisplayPoint[] = [];
  for (const vp of validatedPoints) {
    const dp: DisplayPoint = {
      latitude: vp.raw.latitude,
      longitude: vp.raw.longitude,
      segment: 0,
      kind: vp.decision,
    };
    if (vp.decision === 'pending') pending.push(dp);
    if (vp.decision === 'rejected') rejected.push(dp);
  }
  return { pending, rejected };
}
