/**
 * Session state machine + incremental session data (requirements 7, 8).
 *
 * The reducer owns all state transitions; the tracking engine only dispatches
 * intent actions. Distance accumulation happens here from validator results so
 * the numbers persisted and displayed are identical.
 */
import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { distanceMeters } from '../services/distanceCalculator';
import type { AppStateLabel, RawGpsPoint, ValidatedPoint } from '../types/gps';
import type { ValidatorResult } from '../services/pointValidator';
import {
  createEmptyStats,
  type CompletedSessionSummary,
  type GpsSignalLevel,
  type SessionEvent,
  type TrackingSession,
  type TrackingSessionState,
} from '../types/session';
import type { SamplingConfigId } from '../config/samplingConfigs';

export interface TrackingState {
  /** The in-progress session (null when idle). Persisted incrementally. */
  session: TrackingSession | null;
  /** Finished sessions, newest first. */
  history: CompletedSessionSummary[];
  /** Whether we still need to flush unsaved data (throttled persistence). */
  dirtySince: number | null;
}

const initialState: TrackingState = {
  session: null,
  history: [],
  dirtySince: null,
};

function newSession(id: string, configId: SamplingConfigId, now: number): TrackingSession {
  return {
    id,
    state: 'starting',
    samplingConfigId: configId,
    createdAt: now,
    startedAt: null,
    endedAt: null,
    accumulatedActiveDurationMs: 0,
    activeSince: null,
    pauseHistory: [],
    rawPoints: [],
    validatedPoints: [],
    segmentBoundaries: [],
    validatedDistanceM: 0,
    rawDistanceM: 0,
    lastAcceptedPoint: null,
    lastAcceptedAt: null,
    signalLevel: 'unknown',
    lastFixAt: null,
    lastError: null,
    events: [{ at: now, type: 'start' }],
    lastPersistedAt: null,
    stats: createEmptyStats(),
  };
}

/** Valid states we can move to from a given state (kept permissive for POC
 * but transitions are asserted in unit tests). */
const ALLOWED_TRANSITIONS: Record<TrackingSessionState, TrackingSessionState[]> = {
  idle: ['starting', 'error'],
  starting: ['active_good_signal', 'active_weak_signal', 'paused', 'ending', 'error', 'interrupted'],
  active_good_signal: ['active_weak_signal', 'paused', 'ending', 'interrupted', 'error'],
  active_weak_signal: ['active_good_signal', 'paused', 'ending', 'interrupted', 'error'],
  paused: ['resuming', 'ending', 'interrupted', 'error'],
  resuming: ['active_good_signal', 'active_weak_signal', 'paused', 'ending', 'interrupted', 'error'],
  ending: ['completed', 'error'],
  completed: [],
  interrupted: ['resuming', 'ending', 'completed'],
  error: ['starting', 'idle'],
};

function canTransition(from: TrackingSessionState, to: TrackingSessionState): boolean {
  return ALLOWED_TRANSITIONS[from].includes(to);
}

function closeActiveTiming(session: TrackingSession, now: number): TrackingSession {
  if (session.activeSince !== null) {
    return {
      ...session,
      accumulatedActiveDurationMs:
        session.accumulatedActiveDurationMs + Math.max(0, now - session.activeSince),
      activeSince: null,
    };
  }
  return session;
}

function pushEvent(session: TrackingSession, ev: SessionEvent): SessionEvent[] {
  const events = [...session.events, ev];
  // Cap event timeline to keep persistence light.
  return events.length > 500 ? events.slice(events.length - 500) : events;
}

const trackingSlice = createSlice({
  name: 'tracking',
  initialState,
  reducers: {
    startSession(
      state,
      action: PayloadAction<{ sessionId: string; configId: SamplingConfigId; now: number }>,
    ) {
      state.session = newSession(action.payload.sessionId, action.payload.configId, action.payload.now);
      state.dirtySince = action.payload.now;
    },

    /** Engine reports first fix → session becomes active. */
    sessionRunning(state, action: PayloadAction<{ now: number }>) {
      if (!state.session) return;
      const s = state.session;
      if (s.state === 'starting') {
        s.state = 'active_good_signal';
        s.startedAt = action.payload.now;
        s.activeSince = action.payload.now;
        s.events = pushEvent(s, { at: action.payload.now, type: 'state', detail: 'active_good_signal' });
      }
      state.dirtySince = action.payload.now;
    },

    /**
     * A raw point arrived (already converted). Update raw list + stats.
     * Distance/validated updates happen in pointValidated.
     */
    rawPointReceived(state, action: PayloadAction<{ point: RawGpsPoint }>) {
      if (!state.session) return;
      const s = state.session;
      const p = action.payload.point;
      // Incremental raw distance over the last raw point (diagnostic only).
      const prev = s.rawPoints.length > 0 ? s.rawPoints[s.rawPoints.length - 1] : null;
      if (prev) {
        s.rawDistanceM += distanceMeters(prev, p);
      }
      s.rawPoints.push(p);
      // Cap raw points to bound memory/persistence size for long sessions.
      if (s.rawPoints.length > 20_000) {
        s.rawPoints.splice(0, s.rawPoints.length - 20_000);
      }
      s.stats.rawCount += 1;
      s.stats.pointsByAppState[p.appState] = (s.stats.pointsByAppState[p.appState] ?? 0) + 1;
      if (s.lastFixAt !== null) {
        s.stats.callbackIntervalsMs.push(p.timestamp - s.lastFixAt);
        if (s.stats.callbackIntervalsMs.length > 2000) {
          s.stats.callbackIntervalsMs.splice(0, s.stats.callbackIntervalsMs.length - 2000);
        }
      }
      s.lastFixAt = p.timestamp;
    },

    /** Validator produced a decision for a point. */
    pointValidated(state, action: PayloadAction<{ result: ValidatorResult; now: number }>) {
      if (!state.session) return;
      const s = state.session;
      const { result, now } = action.payload;
      const vp: ValidatedPoint = result.point;

      s.validatedPoints.push(vp);
      if (s.validatedPoints.length > 20_000) {
        s.validatedPoints.splice(0, s.validatedPoints.length - 20_000);
      }

      if (vp.decision === 'accepted') {
        s.stats.acceptedCount += 1;
        if (vp.raw.accuracy !== null) {
          s.stats.acceptedAccuracies.push(vp.raw.accuracy);
          if (s.stats.acceptedAccuracies.length > 5000) {
            s.stats.acceptedAccuracies.splice(0, s.stats.acceptedAccuracies.length - 5000);
          }
        }
        if (result.addedDistance) {
          s.validatedDistanceM += result.distanceAddedM;
          s.stats.acceptedSegments += 1;
        }
        if (result.newAnchor) {
          // Mark a segment boundary so the map never connects across it.
          s.segmentBoundaries.push(s.validatedPoints.length - 1);
        }
        s.lastAcceptedPoint =
          vp.reason === 'micro_movement' ? { ...vp.raw, speed: null } : vp.raw;
        s.lastAcceptedAt = vp.raw.timestamp;
      } else if (vp.decision === 'pending') {
        s.stats.pendingCount += 1;
      } else {
        s.stats.rejectedCount += 1;
        const reason = vp.reason ?? 'unknown';
        s.stats.rejectionReasons[reason] = (s.stats.rejectionReasons[reason] ?? 0) + 1;
        if (reason !== 'paused') {
          s.stats.rejectedSegments += 1;
        }
      }

      if (result.gapDetected) {
        s.stats.gpsGapCount += 1;
        s.events = pushEvent(s, { at: now, type: 'gps_gap' });
      }
      if (result.excessiveSpeedDetected) {
        s.stats.excessiveSpeedSegments += 1;
      }

      state.dirtySince = now;
    },

    setSignalLevel(state, action: PayloadAction<{ level: GpsSignalLevel; now: number }>) {
      if (!state.session) return;
      const s = state.session;
      if (s.signalLevel === action.payload.level) return;
      s.signalLevel = action.payload.level;
      if (
        s.state === 'active_good_signal' ||
        s.state === 'active_weak_signal'
      ) {
        // Weak signal: active timer continues, distance accumulation pauses
        // naturally because no points get accepted (requirement 7).
        s.state = action.payload.level === 'weak' || action.payload.level === 'none'
          ? 'active_weak_signal'
          : 'active_good_signal';
        s.events = pushEvent(s, { at: action.payload.now, type: 'state', detail: s.state });
      }
    },

    pauseSession(state, action: PayloadAction<{ now: number }>) {
      if (!state.session) return;
      const s = state.session;
      if (!canTransition(s.state, 'paused')) return;
      const closed = closeActiveTiming(s, action.payload.now);
      s.accumulatedActiveDurationMs = closed.accumulatedActiveDurationMs;
      s.activeSince = null;
      s.state = 'paused';
      s.pauseHistory.push({ startedAt: action.payload.now, endedAt: null });
      s.events = pushEvent(s, { at: action.payload.now, type: 'pause' });
      state.dirtySince = action.payload.now;
    },

    resumeSession(state, action: PayloadAction<{ now: number }>) {
      if (!state.session) return;
      const s = state.session;
      if (!canTransition(s.state, 'resuming')) return;
      s.state = 'resuming';
      const openPause = [...s.pauseHistory].reverse().find(p => p.endedAt === null);
      if (openPause) {
        openPause.endedAt = action.payload.now;
      }
      s.events = pushEvent(s, { at: action.payload.now, type: 'resume' });
      // resuming → next trusted point becomes anchor; engine handles it.
      state.dirtySince = action.payload.now;
    },

    /** After resume, first trusted point arrived → back to active. */
    resumed(state, action: PayloadAction<{ now: number; level: GpsSignalLevel }>) {
      if (!state.session) return;
      const s = state.session;
      if (s.state !== 'resuming') return;
      s.state = action.payload.level === 'good' ? 'active_good_signal' : 'active_weak_signal';
      s.activeSince = action.payload.now;
      s.events = pushEvent(s, { at: action.payload.now, type: 'state', detail: s.state });
    },

    endSession(state, action: PayloadAction<{ now: number; interrupted?: boolean }>) {
      if (!state.session) return;
      const s = state.session;
      const target: TrackingSessionState = action.payload.interrupted ? 'interrupted' : 'ending';
      if (s.state !== 'interrupted') {
        if (!canTransition(s.state, target)) return;
        s.state = target;
      }
      const closed = closeActiveTiming(s, action.payload.now);
      s.accumulatedActiveDurationMs = closed.accumulatedActiveDurationMs;
      s.activeSince = null;
      const openPause = [...s.pauseHistory].reverse().find(p => p.endedAt === null);
      if (openPause) {
        openPause.endedAt = action.payload.now;
      }
      s.events = pushEvent(s, { at: action.payload.now, type: action.payload.interrupted ? 'state' : 'stop', detail: s.state });
      state.dirtySince = action.payload.now;
    },

    /** Store a human-readable location-provider error hint. */
    setLastError(state, action: PayloadAction<{ message: string | null }>) {
      if (!state.session) return;
      state.session.lastError = action.payload.message;
      state.session.events = pushEvent(state.session, {
        at: Date.now(),
        type: action.payload.message ? 'error' : 'state',
        detail: action.payload.message ?? 'cleared',
      });
    },

    /** Move an ending/interrupted session to history. */
    completeSession(state, action: PayloadAction<{ now: number }>) {
      if (!state.session) return;
      const s = state.session;
      if (s.state !== 'ending' && s.state !== 'interrupted') return;
      s.state = 'completed';
      s.endedAt = action.payload.now;
      const pauseDurationMs = s.pauseHistory.reduce(
        (acc, p) => acc + Math.max(0, (p.endedAt ?? action.payload.now) - p.startedAt),
        0,
      );
      const summary: CompletedSessionSummary = {
        id: s.id,
        startedAt: s.startedAt ?? s.createdAt,
        endedAt: action.payload.now,
        state: s.state,
        samplingConfigId: s.samplingConfigId,
        activeDurationMs: s.accumulatedActiveDurationMs,
        pauseDurationMs,
        rawDistanceM: s.rawDistanceM,
        validatedDistanceM: s.validatedDistanceM,
        acceptedCount: s.stats.acceptedCount,
        rejectedCount: s.stats.rejectedCount,
        session: { ...s, endedAt: action.payload.now },
      };
      state.history.unshift(summary);
      if (state.history.length > 50) {
        state.history.length = 50;
      }
      state.session = null;
      state.dirtySince = null;
    },

    markPersisted(state, action: PayloadAction<{ now: number }>) {
      if (!state.session) return;
      state.session.lastPersistedAt = action.payload.now;
      state.dirtySince = null;
    },

    appStateChanged(state, action: PayloadAction<{ appState: AppStateLabel; now: number }>) {
      if (!state.session) return;
      state.session.events = pushEvent(state.session, {
        at: action.payload.now,
        type: 'app_state',
        detail: action.payload.appState,
      });
    },

    /** Restore an unfinished session after app restart (requirement 8). */
    restoreSession(state, action: PayloadAction<{ session: TrackingSession }>) {
      const incoming = action.payload.session;
      // Close active timing WITHOUT crediting (now - activeSince) as active.
      // The persisted activeSince is from BEFORE the process died; we don't
      // know when the app actually stopped running, so adding the full
      // elapsed time would inflate "active time" by potentially hours of
      // dead time. Time accumulated across previous pauses is already in
      // accumulatedActiveDurationMs. The user must explicitly Resume to
      // restart the active timer (Resume → first accepted point → resumed
      // action sets a fresh activeSince).
      state.session = { ...incoming, state: 'interrupted', activeSince: null };
      state.session.events = pushEvent(state.session, {
        at: Date.now(),
        type: 'restore',
        detail: 'restored unfinished session',
      });
    },

    setSamplingConfig(state, action: PayloadAction<{ configId: SamplingConfigId }>) {
      if (!state.session) return;
      state.session.samplingConfigId = action.payload.configId;
    },

    recordLongestGap(state, action: PayloadAction<{ gapMs: number }>) {
      if (!state.session) return;
      if (action.payload.gapMs > state.session.stats.longestGapMs) {
        state.session.stats.longestGapMs = action.payload.gapMs;
      }
    },

    clearHistory(state) {
      state.history = [];
    },
  },
});

export const {
  startSession,
  sessionRunning,
  rawPointReceived,
  pointValidated,
  setSignalLevel,
  pauseSession,
  resumeSession,
  resumed,
  endSession,
  completeSession,
  setLastError,
  markPersisted,
  appStateChanged,
  restoreSession,
  setSamplingConfig,
  recordLongestGap,
  clearHistory,
} = trackingSlice.actions;

export default trackingSlice.reducer;
