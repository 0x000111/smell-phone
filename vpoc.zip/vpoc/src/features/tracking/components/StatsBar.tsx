import React, { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { GpsSignalLevel, TrackingSessionState } from '../types/session';

interface Props {
  distanceM: number;
  activeDurationMs: number;
  signal: GpsSignalLevel;
  state: TrackingSessionState;
  accuracy: number | null;
  speedMps: number | null;
  lastError: string | null;
  /** Dynamic top offset (status-bar inset + top bar height) — absolute
   * positioning ignores SafeAreaView padding, so the caller must pass it. */
  top: number;
}

const SIGNAL_COLOR: Record<GpsSignalLevel, string> = {
  good: '#2ecc71',
  weak: '#f1c40f',
  none: '#e74c3c',
  unknown: '#95a5a6',
};

const SIGNAL_LABEL: Record<GpsSignalLevel, string> = {
  good: 'GPS good',
  weak: 'GPS weak',
  none: 'No signal',
  unknown: 'Waiting…',
};

function formatDuration(ms: number): string {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(sec).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

function formatDistance(m: number): string {
  if (m >= 1000) return `${(m / 1000).toFixed(2)} km`;
  return `${Math.round(m)} m`;
}

function StatsBar({ distanceM, activeDurationMs, signal, state, accuracy, speedMps, lastError, top }: Props) {
  return (
    <View style={[styles.container, { top }]}>
      <View style={styles.row}>
        <Text style={styles.distance}>{formatDistance(distanceM)}</Text>
        <View style={[styles.signalDot, { backgroundColor: SIGNAL_COLOR[signal] }]} />
        <Text style={styles.signalText}>{SIGNAL_LABEL[signal]}</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.metric}>⏱ {formatDuration(activeDurationMs)}</Text>
        <Text style={styles.metric}>
          ±{accuracy !== null ? Math.round(accuracy) + ' m' : '--'}
        </Text>
        <Text style={styles.metric}>
          {speedMps !== null ? (speedMps * 3.6).toFixed(1) + ' km/h' : '-- km/h'}
        </Text>
      </View>
      {lastError ? (
        <Text style={styles.error}>{lastError}</Text>
      ) : null}
      {state === 'active_weak_signal' ? (
        <Text style={styles.warning}>Distance accumulation paused (weak GPS)</Text>
      ) : null}
      {state === 'paused' ? <Text style={styles.warning}>Paused — timer stopped</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 56,
    left: 12,
    right: 12,
    backgroundColor: 'rgba(20,24,35,0.88)',
    borderRadius: 14,
    padding: 14,
  },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  distance: { color: '#fff', fontSize: 30, fontWeight: '700' },
  signalDot: { width: 10, height: 10, borderRadius: 5, marginRight: 6 },
  signalText: { color: '#fff', fontSize: 14, flex: 1 },
  metric: { color: '#cfd6e4', fontSize: 14, marginRight: 12 },
  warning: { color: '#f1c40f', fontSize: 12, marginTop: 6 },
  error: { color: '#e74c3c', fontSize: 12, marginTop: 6, lineHeight: 17 },
});

export default memo(StatsBar);
