/**
 * Google Maps view with segmented Polylines (requirement 10).
 *
 * - Default Polyline connects only accepted points, split into segments at
 *   every gap/pause boundary (requirement 10.1/10.2).
 * - Debug mode additionally renders raw track (grey), pending (yellow) and
 *   rejected (red) points (requirement 10.3).
 * - Auto-follow can be toggled; user gestures do NOT force the camera back
 *   (requirement 10.4/10.5).
 * - Display points may be simplified; validated data is never mutated
 *   (requirement 10.7).
 */
import React, { memo, useCallback, useMemo, useRef } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE, type Region } from 'react-native-maps';
import { hasMapsKey } from '../config/mapsConfig';
import { groupBySegment, simplifyForDisplay, toDisplayPoints, debugDisplayPoints } from '../utils/trackSimplification';
import type { TrackingSession } from '../types/session';

interface Props {
  session: TrackingSession | null;
  debugMode: boolean;
  followUser: boolean;
  onUserGesture: () => void;
}

const DEFAULT_REGION = {
  latitude: 31.2304,
  longitude: 121.4737,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

/** Simplify when a segment grows beyond this many points. */
const SIMPLIFY_THRESHOLD = 800;

function TrackMap({ session, debugMode, followUser, onUserGesture }: Props) {
  const mapRef = useRef<React.ComponentRef<typeof MapView>>(null);

  const segments = useMemo(() => {
    if (!session) return [];
    const display = toDisplayPoints(session.validatedPoints, session.segmentBoundaries);
    const grouped = groupBySegment(display);
    return grouped.map(seg =>
      seg.length > SIMPLIFY_THRESHOLD
        ? simplifyForDisplay(seg, 0.00002) // ~2m at this latitude
        : seg,
    );
  }, [session]);

  const lastAccepted = session?.lastAcceptedPoint ?? null;

  const debugData = useMemo(() => {
    if (!debugMode || !session) return null;
    const { pending, rejected } = debugDisplayPoints(session.validatedPoints);
    const raw = session.rawPoints.map(p => ({ latitude: p.latitude, longitude: p.longitude }));
    return { pending, rejected, raw };
  }, [debugMode, session]);

  const region = useMemo<Region | undefined>(() => {
    if (lastAccepted) {
      return {
        latitude: lastAccepted.latitude,
        longitude: lastAccepted.longitude,
        latitudeDelta: 0.008,
        longitudeDelta: 0.008,
      };
    }
    return undefined;
  }, [lastAccepted]);

  const handleRegionChange = useCallback(() => {
    // Ignore programmatic follow updates; user gestures set the guard via
    // onPanDrag/onRegionChangeComplete below.
  }, []);

  if (!hasMapsKey()) {
    return (
      <View style={styles.noKey}>
        <Text style={styles.noKeyTitle}>Google Maps API key not configured</Text>
        <Text style={styles.noKeyBody}>
          Copy .env.example → create src/features/tracking/config/mapsKeys.local.ts
          {'\n'}with your own key (git-ignored). Tracking still works without a key.
        </Text>
      </View>
    );
  }

  return (
    <MapView
      ref={mapRef}
      provider={PROVIDER_GOOGLE}
      style={StyleSheet.absoluteFill}
      initialRegion={DEFAULT_REGION}
      region={followUser && lastAccepted ? region : undefined}
      onPanDrag={() => {
        onUserGesture();
      }}
      onRegionChange={handleRegionChange}
      showsUserLocation={false}
    >
      {segments.map((seg, i) => (
        <Polyline
          key={`seg-${i}`}
          coordinates={seg}
          strokeColor="#2b7cff"
          strokeWidth={4}
          lineJoin="round"
        />
      ))}

      {debugData ? (
        <>
          <Polyline
            coordinates={debugData.raw}
            strokeColor="rgba(150,150,150,0.35)"
            strokeWidth={1.5}
          />
          {debugData.pending.map((p, i) => (
            <Marker
              key={`pend-${i}`}
              coordinate={{ latitude: p.latitude, longitude: p.longitude }}
              pinColor="yellow"
              flat
            />
          ))}
          {debugData.rejected.map((p, i) => (
            <Marker
              key={`rej-${i}`}
              coordinate={{ latitude: p.latitude, longitude: p.longitude }}
              pinColor="red"
              flat
            />
          ))}
        </>
      ) : null}

      {lastAccepted ? (
        <Marker
          coordinate={{ latitude: lastAccepted.latitude, longitude: lastAccepted.longitude }}
          title="Last accepted position"
          description={`±${Math.round(lastAccepted.accuracy ?? 0)} m`}
        />
      ) : null}
    </MapView>
  );
}

const styles = StyleSheet.create({
  noKey: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1a1f2e',
    padding: 24,
  },
  noKeyTitle: { color: '#fff', fontSize: 16, fontWeight: '600', marginBottom: 8, textAlign: 'center' },
  noKeyBody: { color: '#9aa4b8', fontSize: 13, textAlign: 'center', lineHeight: 19 },
});

export default memo(TrackMap);
