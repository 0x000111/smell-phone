/**
 * Centralised filtering thresholds (requirement 6.2 / 13.2.10).
 *
 * ALL GPS filtering thresholds live here — nothing is scattered in components.
 * These are POC starting values, NOT final business rules; adjust after real
 * device testing. Business decisions still open (requirement 16) are exposed
 * as switches rather than hard-coded.
 */

export interface FilterConfig {
  /** accuracy <= acceptAccuracyM → eligible for validation. */
  acceptAccuracyM: number;
  /** acceptAccuracyM < accuracy <= pendingAccuracyM → pending buffer. */
  pendingAccuracyM: number;
  /** accuracy > pendingAccuracyM → rejected (poor_accuracy), kept in raw. */
  /** How many later points are needed to confirm a pending point. */
  pendingConfirmCount: number;
  /** Max pending buffer size (oldest dropped if exceeded). */
  maxPendingBuffer: number;

  /** If no accepted point for this long, next fix becomes anchor only. */
  gpsGapThresholdMs: number;

  /**
   * Minimum displacement (metres) between consecutive accepted points for
   * the segment to count toward validated distance. Fixes closer than this
   * are GPS jitter (a stationary phone drifts 1-3 m per fix): they stay
   * accepted for display but do NOT move the anchor and do NOT add distance.
   * Without this gate, random-walk jitter accumulates phantom distance
   * (~18 m observed on a desk in 15 min with the fused provider).
   */
  minMovementM: number;

  /** Absolute sanity bounds. */
  maxValidLatitude: number;
  maxValidLongitude: number;

  /** Segment rejected as impossible jump if implied speed exceeds this. */
  maxImpliedSpeedMps: number;
  /** Also require the jump distance to be at least this many metres. */
  minJumpDistanceM: number;

  /** Excessive-speed detection (requirement 6.4). */
  speedFilterEnabled: boolean;
  /** Speed threshold in m/s (20 km/h ≈ 5.56 m/s). Configurable. */
  speedThresholdMps: number;
  /** Consecutive points over threshold before marking a segment. */
  excessiveSpeedConsecutivePoints: number;
  /** Or sustained seconds over threshold before marking. */
  excessiveSpeedSustainMs: number;
  /** When true, excessive speed ends the session. Default false: only
   * reject the segment, keep prior distance (requirement 6.4). */
  endSessionOnExcessiveSpeed: boolean;

  /** Stale fix: device timestamp older than this vs receivedAt. */
  staleTimestampToleranceMs: number;

  /** Weak-signal UI threshold: no fix for this long → 'none'. */
  noSignalAfterMs: number;
  /** accuracy worse than pendingAccuracyM for this long → 'weak'. */
  weakSignalAfterMs: number;

  /** Idle detection (optional experiment, requirement 7). */
  idleDetectionEnabled: boolean;
  /** Show a hint after this long with no validated movement. */
  idleHintAfterMs: number;

  /**
   * Android location provider toggle. When true, uses raw LocationManager
   * (GPS_PROVIDER only). When false, uses the Google Play Services fused
   * provider which falls back to network (cell/WiFi) — required to get any
   * fix indoors or in urban canyons where pure GPS cannot lock.
   *
   * The POC's intent is to validate raw-GPS quality; the default here is
   * false so the app works in the typical indoor / weak-sky scenarios. Flip
   * to true from Settings for raw-GPS quality testing.
   */
  forceLocationManager: boolean;
}

export const DEFAULT_FILTER_CONFIG: FilterConfig = {
  acceptAccuracyM: 35,
  pendingAccuracyM: 50,
  pendingConfirmCount: 2,
  maxPendingBuffer: 8,

  gpsGapThresholdMs: 30_000,

  minMovementM: 3,

  maxValidLatitude: 90,
  maxValidLongitude: 180,

  maxImpliedSpeedMps: 50, // 180 km/h — clearly impossible for any activity
  minJumpDistanceM: 50,

  speedFilterEnabled: true,
  speedThresholdMps: 20 / 3.6, // 20 km/h
  excessiveSpeedConsecutivePoints: 3,
  excessiveSpeedSustainMs: 10_000,
  endSessionOnExcessiveSpeed: false,

  staleTimestampToleranceMs: 60_000,

  noSignalAfterMs: 15_000,
  weakSignalAfterMs: 10_000,

  idleDetectionEnabled: false,
  idleHintAfterMs: 120_000,

  forceLocationManager: false,
};
