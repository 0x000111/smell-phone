/**
 * Google Maps API key resolution (requirement 3.2 / 15.14).
 *
 * The key must NEVER be hard-coded or committed. It is read from a local,
 * git-ignored config module (`mapsKeys.local.ts`) if present, otherwise a
 * placeholder is returned and the UI shows a clear "no key configured"
 * message instead of crashing (requirement Phase 1).
 */

export const MAPS_KEY_PLACEHOLDER = 'YOUR_GOOGLE_MAPS_API_KEY';

let localKey: string | null = null;
try {
  // Optional, git-ignored file. Absent in a fresh checkout — that is fine.

  const mod = require('./mapsKeys.local');
  const candidate = mod?.GOOGLE_MAPS_API_KEY;
  if (typeof candidate === 'string' && candidate.length > 0 && candidate !== MAPS_KEY_PLACEHOLDER) {
    localKey = candidate;
  }
} catch {
  localKey = null;
}

export function getMapsApiKey(): string | null {
  return localKey;
}

export function hasMapsKey(): boolean {
  return localKey !== null;
}
