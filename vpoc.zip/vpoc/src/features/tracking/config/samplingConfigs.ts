/**
 * Three sampling profiles (requirement 5.2). Platform-specific options are
 * kept separate so we never pass an unsupported option to a platform
 * (requirement 5.2 / 3.1).
 *
 * IMPORTANT: `interval` is a TARGET, not a guarantee. The real callback
 * cadence is measured at runtime (see diagnostics).
 */
import type { GeoWatchOptions } from 'react-native-geolocation-service';

export type SamplingConfigId = 'high' | 'balanced' | 'battery';

export interface SamplingProfile {
  id: SamplingConfigId;
  label: string;
  description: string;
  /** Target interval in ms. */
  targetIntervalMs: number;
  /** distanceFilter in metres. */
  distanceFilterM: number;
  /** Watch options split per platform so we don't mix unsupported options. */
  ios: Pick<GeoWatchOptions, 'interval' | 'distanceFilter' | 'accuracy' | 'showLocationDialog' | 'forceLocationManager'>;
  android: Pick<GeoWatchOptions, 'interval' | 'fastestInterval' | 'distanceFilter' | 'accuracy' | 'showLocationDialog' | 'forceLocationManager'>;
}

export const SAMPLING_PROFILES: Record<SamplingConfigId, SamplingProfile> = {
  high: {
    id: 'high',
    label: 'High Accuracy',
    description: '~2-3s interval, 5m filter. Best track quality, higher battery.',
    targetIntervalMs: 2500,
    distanceFilterM: 5,
    ios: {
      interval: 2500,
      distanceFilter: 5,
      accuracy: { ios: 'bestForNavigation' },
      showLocationDialog: true,
    },
    android: {
      interval: 2500,
      fastestInterval: 1000,
      distanceFilter: 5,
      accuracy: { android: 'high' },
      showLocationDialog: true,
    },
  },
  balanced: {
    id: 'balanced',
    label: 'Balanced',
    description: '~5s interval, 10m filter. Candidate for the real product.',
    targetIntervalMs: 5000,
    distanceFilterM: 10,
    ios: {
      interval: 5000,
      distanceFilter: 10,
      accuracy: { ios: 'nearestTenMeters' },
      showLocationDialog: true,
    },
    android: {
      interval: 5000,
      fastestInterval: 2000,
      distanceFilter: 10,
      accuracy: { android: 'high' },
      showLocationDialog: true,
    },
  },
  battery: {
    id: 'battery',
    label: 'Battery Saving',
    description: '~10s interval, 20m filter. Observe track loss vs battery.',
    targetIntervalMs: 10000,
    distanceFilterM: 20,
    ios: {
      interval: 10000,
      distanceFilter: 20,
      accuracy: { ios: 'hundredMeters' },
      showLocationDialog: true,
    },
    android: {
      interval: 10000,
      fastestInterval: 5000,
      distanceFilter: 20,
      accuracy: { android: 'balanced' },
      showLocationDialog: true,
    },
  },
};

export function getWatchOptions(
  id: SamplingConfigId,
  platform: 'ios' | 'android',
): GeoWatchOptions {
  const p = SAMPLING_PROFILES[id];
  return platform === 'ios' ? { ...p.ios } : { ...p.android };
}
