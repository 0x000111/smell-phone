/**
 * LOCAL Google Maps key file — git-ignored. Contains a PLACEHOLDER only.
 * Replace the value with your own key for real map rendering. The app runs
 * without a real key (map area shows a "key not configured" notice).
 */
export const GOOGLE_MAPS_API_KEY = 'AIzaSyAGL4vu-4sW4fPfV1dVt87ZFrh4DVb0Ckk';
