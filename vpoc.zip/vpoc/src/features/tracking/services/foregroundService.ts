/**
 * Android foreground-service wrapper (requirement 3.1 / Phase 4).
 *
 * Uses @voximplant/react-native-foreground-service ONLY on Android to keep
 * location callbacks alive when the app is backgrounded. iOS relies on the
 * `location` background mode configured in Info.plist instead.
 *
 * All failures are non-fatal for the POC: if the service cannot start (e.g.
 * missing notification permission on Android 13+), tracking still runs in the
 * foreground and the failure is logged for diagnostics.
 */
import { Platform } from 'react-native';
import VIForegroundService from '@voximplant/react-native-foreground-service';
import type { SamplingConfigId } from '../config/samplingConfigs';
import { SAMPLING_PROFILES } from '../config/samplingConfigs';

const CHANNEL_ID = 'gps-tracking-poc';
const NOTIFICATION_ID = 42;

export class ForegroundService {
  private started = false;

  async startTracking(configId: SamplingConfigId): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return true; // iOS uses background location mode; nothing to do here.
    }
    try {
      await VIForegroundService.createNotificationChannel({
        id: CHANNEL_ID,
        name: 'GPS Tracking',
        description: 'Keeps GPS tracking alive in the background',
        importance: 3,
      });
      const profile = SAMPLING_PROFILES[configId];
      await VIForegroundService.startService({
        channelId: CHANNEL_ID,
        id: NOTIFICATION_ID,
        title: 'Virtual Walk POC',
        text: `Tracking active (${profile.label})`,
        icon: 'ic_launcher',
        priority: 2,
      });
      this.started = true;
      return true;
    } catch (e) {
      console.warn('[foregroundService] start failed', e);
      return false;
    }
  }

  async stopTracking(): Promise<boolean> {
    if (Platform.OS !== 'android' || !this.started) {
      return true;
    }
    try {
      await VIForegroundService.stopService();
    } catch (e) {
      console.warn('[foregroundService] stop failed', e);
    }
    this.started = false;
    return true;
  }
}

export const foregroundService = new ForegroundService();
