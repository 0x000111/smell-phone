/**
 * Incremental, throttled persistence of the in-progress session (requirement 8).
 *
 * We do NOT write on every GPS callback — writes are throttled (default every
 * 5s and only when dirty). On app start we look for an unfinished session and
 * expose it for restore. Completed sessions live in redux-persist history.
 *
 * Storage backend: AsyncStorage (via redux-persist for history; a dedicated
 * key for the in-flight session so we can restore even if redux-persist's
 * flush ordering is mid-write).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { TrackingSession } from '../types/session';

const ACTIVE_KEY = '@gpspoc/activeSession';
const EXPORT_DIR = '@gpspoc/exports';

export interface RestoreResult {
  found: boolean;
  session: TrackingSession | null;
}

export class SessionPersistence {
  private lastWriteAt = 0;
  private writeTimer: ReturnType<typeof setTimeout> | null = null;
  private pending: TrackingSession | null = null;

  constructor(private throttleMs = 5_000) {}

  /**
   * Schedule a throttled write. Coalesces bursts of GPS callbacks into at most
   * one write per throttleMs.
   */
  scheduleSave(session: TrackingSession): void {
    this.pending = session;
    const now = Date.now();
    const elapsed = now - this.lastWriteAt;
    if (elapsed >= this.throttleMs) {
      this.flush();
    } else if (!this.writeTimer) {
      this.writeTimer = setTimeout(() => {
        this.writeTimer = null;
        this.flush();
      }, this.throttleMs - elapsed);
    }
  }

  /** Immediate write (used on stop/pause and app background). */
  async saveNow(session: TrackingSession): Promise<void> {
    this.pending = session;
    await this.flush();
  }

  async flush(): Promise<void> {
    if (!this.pending) return;
    const snapshot = this.pending;
    this.pending = null;
    try {
      await AsyncStorage.setItem(ACTIVE_KEY, JSON.stringify(snapshot));
      this.lastWriteAt = Date.now();
    } catch (e) {
      console.warn('[persistence] save failed', e);
    }
  }

  async loadActive(): Promise<RestoreResult> {
    try {
      const raw = await AsyncStorage.getItem(ACTIVE_KEY);
      if (!raw) return { found: false, session: null };
      const session = JSON.parse(raw) as TrackingSession;
      // Only "unfinished" if not completed.
      if (session.state === 'completed') {
        await AsyncStorage.removeItem(ACTIVE_KEY);
        return { found: false, session: null };
      }
      return { found: true, session };
    } catch (e) {
      console.warn('[persistence] load failed', e);
      return { found: false, session: null };
    }
  }

  async clearActive(): Promise<void> {
    this.pending = null;
    if (this.writeTimer) {
      clearTimeout(this.writeTimer);
      this.writeTimer = null;
    }
    await AsyncStorage.removeItem(ACTIVE_KEY);
  }

  /** Export the current session diagnostics as a local JSON file (requirement 9.2). */
  async exportSessionJson(session: TrackingSession): Promise<string> {
    // We store the JSON blob under a namespaced key rather than the filesystem,
    // keeping the POC free of extra native file deps. react-native-fs is used
    // in the UI layer to write the actual file if available.
    const key = `${EXPORT_DIR}/${session.id}`;
    await AsyncStorage.setItem(key, JSON.stringify(session));
    return key;
  }
}

export const sessionPersistence = new SessionPersistence();
