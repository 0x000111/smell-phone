/**
 * Tracking engine — orchestrates geolocation → validator → store.
 * Decoupled from React components so the pipeline is testable.
 *
 * Owns: the PointValidator instance, signal-level watchdog, gap bookkeeping,
 * and (Android) the foreground service used to keep location alive in the
 * background. It does NOT own distance math — that lives in the reducer fed
 * by validator results, so persisted and displayed numbers match.
 */
import type { Store } from '@reduxjs/toolkit';
import {
  describeGeoError,
  geolocationService,
  requestLocationPermission,
  type PermissionStatus,
} from './geolocationService';
import { PointValidator } from './pointValidator';
import { DEFAULT_FILTER_CONFIG, type FilterConfig } from '../config/filterConfig';
import type { SamplingConfigId } from '../config/samplingConfigs';
import type { AppStateLabel, RawGpsPoint } from '../types/gps';
import {
  completeSession,
  endSession,
  pauseSession,
  pointValidated,
  rawPointReceived,
  recordLongestGap,
  resumeSession,
  resumed,
  sessionRunning,
  setLastError,
  setSignalLevel,
  startSession,
} from '../store/trackingSlice';
import type { RootState } from '../../../app/store/store';
import { foregroundService } from './foregroundService';

export type EngineResult =
  | { ok: true }
  | { ok: false; error: string };

export class TrackingEngine {
  private validator: PointValidator;
  private store: Store<RootState> | null = null;
  private running = false;
  private signalTimer: ReturnType<typeof setInterval> | null = null;
  private lastGoodFixAt: number | null = null;
  private pendingResumeAnchor = false;

  constructor(private filterConfig: FilterConfig = DEFAULT_FILTER_CONFIG) {
    this.validator = new PointValidator(filterConfig);
  }

  attachStore(store: Store<RootState>): void {
    this.store = store;
  }

  setFilterConfig(cfg: FilterConfig): void {
    this.filterConfig = cfg;
    this.validator = new PointValidator(cfg);
  }

  isRunning(): boolean {
    return this.running;
  }

  private requireStore(): Store<RootState> {
    if (!this.store) {
      throw new Error('TrackingEngine.attachStore() must be called before use');
    }
    return this.store;
  }

  async checkPermission(): Promise<PermissionStatus> {
    return requestLocationPermission();
  }

  setAppState(appState: AppStateLabel): void {
    geolocationService.setAppState(appState);
    // When the app comes back to the foreground, the watchdog may have
    // marked the session 'none' during a long background period even though
    // the watch is still alive (FGS keeps it running). Re-arm signal so the
    // next GPS fix re-evaluates immediately instead of staying stuck on
    // "no signal".
    if (appState === 'active') {
      const store = this.store;
      if (store) {
        const session = store.getState().tracking.session;
        if (
          session &&
          session.signalLevel === 'none' &&
          (session.state === 'active_good_signal' ||
            session.state === 'active_weak_signal' ||
            session.state === 'starting')
        ) {
          store.dispatch(setSignalLevel({ level: 'unknown', now: Date.now() }));
        }
      }
    }
  }

  async start(configId: SamplingConfigId): Promise<EngineResult> {
    if (this.running) {
      return { ok: false, error: 'already_running' };
    }
    const permission = await requestLocationPermission();
    if (permission === 'denied' || permission === 'restricted') {
      return { ok: false, error: `permission_${permission}` };
    }

    const store = this.requireStore();
    const now = Date.now();
    const sessionId = `sess-${now}`;
    store.dispatch(startSession({ sessionId, configId, now }));

    this.validator = new PointValidator(this.filterConfig);
    this.pendingResumeAnchor = false;
    this.lastGoodFixAt = null;

    return this.beginWatch(configId);
  }

  /**
   * Resume a restored (unfinished) session: keeps the existing session data
   * and distance, re-arms the validator so the next trusted point becomes a
   * fresh anchor, and starts the location watch (requirement 8).
   */
  async resumeRestoredSession(configId: SamplingConfigId): Promise<EngineResult> {
    if (this.running) {
      return { ok: false, error: 'already_running' };
    }
    const permission = await requestLocationPermission();
    if (permission === 'denied' || permission === 'restricted') {
      return { ok: false, error: `permission_${permission}` };
    }
    const store = this.requireStore();
    const session = store.getState().tracking.session;
    if (!session) {
      return { ok: false, error: 'no_session_to_resume' };
    }
    // interrupted → resuming is an allowed transition.
    store.dispatch(resumeSession({ now: Date.now() }));
    this.validator.resetAnchor();
    this.pendingResumeAnchor = true;
    return this.beginWatch(configId);
  }

  private async beginWatch(configId: SamplingConfigId): Promise<EngineResult> {
    const store = this.requireStore();
    this.running = true;

    await foregroundService.startTracking(configId);

    geolocationService.start(configId, {
      onPoint: raw => this.handlePoint(raw),
      onError: err => {
        // Non-fatal: surface the reason to the UI; session stays alive so
        // the user can fix settings (GPS off / permission) without losing
        // accumulated distance.
        const s = store.getState().tracking.session;
        if (s) {
          store.dispatch(setSignalLevel({ level: 'none', now: Date.now() }));
          store.dispatch(setLastError({ message: describeGeoError(err) }));
        }
        console.warn('[tracking] geolocation error', err.code, err.message);
      },
    }, this.filterConfig.forceLocationManager);

    this.startSignalWatchdog();
    return { ok: true };
  }

  private handlePoint(raw: RawGpsPoint): void {
    const store = this.requireStore();
    if (!this.running || !store.getState().tracking.session) {
      return;
    }

    // A successful fix clears any previous provider error hint.
    store.dispatch(setLastError({ message: null }));

    store.dispatch(rawPointReceived({ point: raw }));

    const result = this.validator.validate(raw);
    store.dispatch(pointValidated({ result, now: Date.now() }));

    if (result.gapDetected) {
      // Record the gap length for diagnostics.
      const gapMs = raw.timestamp - (this.lastGoodFixAt ?? raw.timestamp);
      if (gapMs > 0) {
        store.dispatch(recordLongestGap({ gapMs }));
      }
    }

    if (raw.accuracy !== null && raw.accuracy <= this.filterConfig.acceptAccuracyM) {
      this.lastGoodFixAt = raw.timestamp;
    }

    // After a resume, the first accepted point completes the re-anchor.
    if (this.pendingResumeAnchor && result.point.decision === 'accepted') {
      this.pendingResumeAnchor = false;
      store.dispatch(
        resumed({ now: Date.now(), level: this.computeSignalLevel(raw) }),
      );
    }

    // Transition starting → running on first point.
    const session = store.getState().tracking.session;
    if (session && session.state === 'starting') {
      store.dispatch(sessionRunning({ now: Date.now() }));
    }

    // Keep signal level fresh.
    store.dispatch(
      setSignalLevel({ level: this.computeSignalLevel(raw), now: Date.now() }),
    );
  }

  private computeSignalLevel(raw: RawGpsPoint): 'good' | 'weak' {
    if (raw.accuracy === null) return 'weak';
    if (raw.accuracy <= this.filterConfig.acceptAccuracyM) return 'good';
    return 'weak';
  }

  private startSignalWatchdog(): void {
    this.stopSignalWatchdog();
    this.signalTimer = setInterval(() => {
      const store = this.store;
      if (!store) return;
      const session = store.getState().tracking.session;
      if (!session) return;
      if (session.state === 'paused' || session.state === 'resuming') return;

      const now = Date.now();
      const sinceLast = session.lastFixAt ? now - session.lastFixAt : Infinity;
      if (sinceLast > this.filterConfig.noSignalAfterMs) {
        store.dispatch(setSignalLevel({ level: 'none', now }));
        if (session.lastFixAt) {
          store.dispatch(recordLongestGap({ gapMs: sinceLast }));
        } else if (session.lastError === null) {
          // Never received a fix: most likely the system location switch is
          // OFF (LocationManager fails silently on Xiaomi in that case).
          store.dispatch(
            setLastError({
              message:
                'No GPS fix yet. On Xiaomi: pull down quick settings and turn ON "Location" (定位服务), then step outdoors.',
            }),
          );
        }
      }
    }, 5_000);
  }

  private stopSignalWatchdog(): void {
    if (this.signalTimer) {
      clearInterval(this.signalTimer);
      this.signalTimer = null;
    }
  }

  pause(): void {
    const store = this.requireStore();
    if (!this.running) return;
    this.validator.setPaused(true);
    store.dispatch(pauseSession({ now: Date.now() }));
  }

  resume(): void {
    const store = this.requireStore();
    if (!this.running) return;
    store.dispatch(resumeSession({ now: Date.now() }));
    // Break trajectory; next trusted point becomes a fresh anchor.
    this.validator.setPaused(false);
    this.validator.resetAnchor();
    this.pendingResumeAnchor = true;
  }

  /**
   * Stop and finalize the session. ALWAYS cleans up state even if the engine
   * never actually received a fix (e.g. GPS was off) — previously this
   * silently returned and the UI appeared frozen.
   */
  async stop(): Promise<void> {
    const store = this.requireStore();
    this.running = false;
    this.stopSignalWatchdog();
    geolocationService.stop();
    await foregroundService.stopTracking();

    const now = Date.now();
    const session = store.getState().tracking.session;
    if (session && session.state !== 'completed') {
      store.dispatch(endSession({ now }));
      store.dispatch(completeSession({ now }));
    }
  }

  /** Called when the process is being torn down / app backgrounded hard. */
  async shutdown(): Promise<void> {
    this.running = false;
    this.stopSignalWatchdog();
    geolocationService.stop();
    await foregroundService.stopTracking();
  }
}

export const trackingEngine = new TrackingEngine();
