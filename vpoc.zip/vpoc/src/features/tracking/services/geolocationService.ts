/**
 * Wrapper around react-native-geolocation-service (requirement 5.1).
 *
 * IMPORTANT platform note: the library's `requestAuthorization` is iOS-only —
 * on Android it REJECTS and never shows a dialog. Android runtime permission
 * MUST be requested via PermissionsAndroid. We also request POST_NOTIFICATIONS
 * on Android 13+ (needed for the foreground-service notification) and force
 * the framework LocationManager on Android so devices without Google Play
 * Services (e.g. many Xiaomi ROMs) still receive GPS fixes.
 */
import { PermissionsAndroid, Platform } from 'react-native';
import Geolocation, {
  type GeoError,
  type GeoPosition,
  type AuthorizationResult,
} from 'react-native-geolocation-service';
import { getWatchOptions, type SamplingConfigId } from '../config/samplingConfigs';
import type { AppStateLabel, RawGpsPoint } from '../types/gps';

export type PermissionStatus =
  | AuthorizationResult
  | 'granted'
  | 'denied'
  | 'unavailable'
  | 'unknown';

let idCounter = 0;
function makeId(): string {
  idCounter += 1;
  return `${Date.now()}-${idCounter}`;
}

/**
 * Request location permission (and notification permission on Android 13+).
 * Returns 'granted' only when the app can actually receive location fixes.
 */
export async function requestLocationPermission(): Promise<PermissionStatus> {
  if (Platform.OS === 'ios') {
    try {
      const res = await Geolocation.requestAuthorization('whenInUse');
      return res; // 'granted' | 'denied' | 'restricted' | 'disabled'
    } catch {
      return 'unknown';
    }
  }

  // Android: request the runtime permissions ourselves.
  try {
    const fine = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: 'Location permission',
        message:
          'GPS tracking needs location access to record your route and distance.',
        buttonPositive: 'Allow',
        buttonNegative: 'Deny',
      },
    );
    // Best-effort notification permission for the foreground service (13+).
    try {
      const notifPerm = (PermissionsAndroid.PERMISSIONS as Record<string, string>)
        .POST_NOTIFICATIONS;
      if (notifPerm) {
        await PermissionsAndroid.request(
          notifPerm as Parameters<typeof PermissionsAndroid.request>[0],
        );
      }
    } catch {
      // ignore — foreground service can still run without notifications UI.
    }

    if (fine === 'granted') {
      // Background tracking needs the SEPARATE "Allow all the time" runtime
      // permission on Android 10+. Declaring it in the manifest is not enough,
      // and it is never granted together with ACCESS_FINE_LOCATION. Without
      // it the system stops delivering fixes as soon as the app leaves the
      // foreground — even with a location-type foreground service running
      // (FGS type satisfies Android 14's startForeground check, but the fused
      // provider still gates background updates on this permission).
      try {
        const bgPerm = (PermissionsAndroid.PERMISSIONS as Record<string, string>)
          .ACCESS_BACKGROUND_LOCATION;
        if (bgPerm && Number(Platform.Version) >= 29) {
          await PermissionsAndroid.request(
            bgPerm as Parameters<typeof PermissionsAndroid.request>[0],
            {
              title: 'Background location',
              message:
                'To keep tracking when the app is in the background or the ' +
                'screen is locked, choose "Allow all the time".',
              buttonPositive: 'Allow',
              buttonNegative: 'Deny',
            },
          );
        }
      } catch {
        // Non-fatal: foreground tracking still works without it.
      }
      return 'granted';
    }
    if (fine === 'never_ask_again' || fine === 'denied') {
      return 'denied';
    }
    return 'unknown';
  } catch {
    return 'unavailable';
  }
}

/** Map a library GeoError code to a human hint for the UI. */
export function describeGeoError(error: GeoError): string {
  switch (error.code) {
    case 1:
      return 'Location permission denied. Enable it in system Settings.';
    case 2:
      return 'Location unavailable. Move to an area with a clearer sky view.';
    case 3:
      return 'Timed out waiting for a GPS fix.';
    case 4:
      return 'Google Play Services unavailable — using the system location provider.';
    case 5:
      return 'Location services are OFF. Turn on GPS / Location in the system quick-settings, then tap Start again.';
    default:
      return error.message || 'Unknown location error.';
  }
}

export interface WatchCallbacks {
  onPoint: (point: RawGpsPoint) => void;
  onError: (error: GeoError) => void;
}

export class GeolocationService {
  private watchId: number | null = null;
  private currentAppState: AppStateLabel = 'unknown';

  setAppState(state: AppStateLabel): void {
    this.currentAppState = state;
  }

  isWatching(): boolean {
    return this.watchId !== null;
  }

  start(configId: SamplingConfigId, callbacks: WatchCallbacks, forceLocationManager = false): void {
    this.stop();
    const platform = Platform.OS === 'ios' ? 'ios' : 'android';
    const options = getWatchOptions(configId, platform);
    // On Android, default to the fused (Google Play Services) provider so
    // the app still gets a fix indoors / urban canyons via cell/WiFi
    // fallback. Flip to true from Settings for raw-GPS quality testing —
    // GPS_PROVIDER alone can yield no fix when satellites are blocked.
    if (platform === 'android') {
      options.forceLocationManager = forceLocationManager;
    }
    this.watchId = Geolocation.watchPosition(
      (position: GeoPosition) => {
        callbacks.onPoint(toRawPoint(position, this.currentAppState));
      },
      (error: GeoError) => {
        callbacks.onError(error);
      },
      options,
    );
  }

  stop(): void {
    if (this.watchId !== null) {
      Geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    try {
      Geolocation.stopObserving();
    } catch {
      // stopObserving may throw if nothing was registered; ignore.
    }
  }
}

export function toRawPoint(
  position: GeoPosition,
  appState: AppStateLabel,
): RawGpsPoint {
  const c = position.coords;
  return {
    id: makeId(),
    latitude: c.latitude,
    longitude: c.longitude,
    timestamp: position.timestamp,
    accuracy: Number.isFinite(c.accuracy) ? c.accuracy : null,
    altitude: c.altitude ?? null,
    altitudeAccuracy: c.altitudeAccuracy ?? null,
    speed: c.speed ?? null,
    heading: c.heading ?? null,
    appState,
    receivedAt: Date.now(),
    provider: position.provider,
    mocked: position.mocked,
  };
}

export const geolocationService = new GeolocationService();
