/**
 * Local diagnostics export (requirement 9.2).
 *
 * Writes the full session as a JSON file to the device's documents directory
 * using react-native-fs. If the native module is unavailable in this build,
 * we fall back to AsyncStorage so the export still succeeds locally.
 *
 * NEVER uploads anywhere. The file stays on the device.
 */
import { Platform } from 'react-native';
import type { TrackingSession } from '../types/session';

interface ExportResult {
  ok: boolean;
  path?: string;
  error?: string;
}

async function tryFsExport(session: TrackingSession): Promise<ExportResult> {
  try {
    // Lazy require so a missing/broken native module cannot crash the app.
     
    const RNFS = require('react-native-fs');
    const dir =
      Platform.OS === 'ios'
        ? `${RNFS.DocumentDirectoryPath}/gpspoc`
        : `${RNFS.ExternalDirectoryPath ?? RNFS.DocumentDirectoryPath}/gpspoc`;
    await RNFS.mkdir(dir);
    const file = `${dir}/session-${session.id}.json`;
    await RNFS.writeFile(file, JSON.stringify(session, null, 2), 'utf8');
    return { ok: true, path: file };
  } catch (e) {
    return { ok: false, error: `fs export failed: ${String(e)}` };
  }
}

export async function exportSessionDiagnostics(
  session: TrackingSession,
): Promise<ExportResult> {
  const fs = await tryFsExport(session);
  if (fs.ok) return fs;

  // Fallback: keep the JSON in AsyncStorage (still local-only).
  try {
    const AsyncStorage = require('@react-native-async-storage/async-storage').default;
    const key = `@gpspoc/export/${session.id}`;
    await AsyncStorage.setItem(key, JSON.stringify(session));
    return {
      ok: true,
      path: `Saved to local storage key: ${key}\n(${fs.error})`,
    };
  } catch (e2) {
    return { ok: false, error: `${fs.error}; storage fallback failed: ${String(e2)}` };
  }
}
