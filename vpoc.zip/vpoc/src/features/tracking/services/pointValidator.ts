/**
 * Point validation pipeline (requirements 5.3, 6, 7).
 *
 * Pure, stateful logic decoupled from React so it can be unit-tested with
 * synthetic coordinates (which MUST be labelled synthetic in tests).
 *
 * Maintains:
 *  - the last accepted anchor (for distance + gap detection)
 *  - a short pending buffer for edge-quality points
 *  - a rolling window for excessive-speed detection
 *
 * Every decision answers "why was this point accepted or rejected".
 */
import {
  distanceMeters,
  impliedSpeedMps,
  type LatLng,
} from './distanceCalculator';
import type {
  PendingPoint,
  PointDecision,
  RawGpsPoint,
  RejectionReason,
  ValidatedPoint,
} from '../types/gps';
import type { FilterConfig } from '../config/filterConfig';

export interface ValidatorResult {
  point: ValidatedPoint;
  /** True when this point extended the validated distance. */
  addedDistance: boolean;
  /** Metres added (0 if not accepted). */
  distanceAddedM: number;
  /** A new anchor was established (gap/pause/resume boundary). */
  newAnchor: boolean;
  /** A GPS gap was detected (session stays active, distance paused). */
  gapDetected: boolean;
  /** An excessive-speed segment was detected (marker only by default). */
  excessiveSpeedDetected: boolean;
}

interface Anchor extends LatLng {
  timestamp: number;
}

export class PointValidator {
  private anchor: Anchor | null = null;
  private pending: PendingPoint[] = [];
  /** Rolling window of recent accepted fixes for speed analysis. */
  private speedWindow: Array<Anchor & { deviceSpeed: number | null }> = [];
  private consecutiveOverSpeed = 0;
  private overSpeedSince: number | null = null;

  /** Whether the session is currently paused (rejects with 'paused'). */
  private paused = false;

  constructor(private readonly config: FilterConfig) {}

  setPaused(paused: boolean): void {
    this.paused = paused;
    // Pausing breaks the trajectory; resume re-anchors (requirement 7).
    if (paused) {
      this.anchor = null;
      this.pending = [];
      this.speedWindow = [];
      this.resetSpeedRun();
    }
  }

  /** Force re-anchoring on next good point (used for resume / restore). */
  resetAnchor(): void {
    this.anchor = null;
    this.pending = [];
    this.speedWindow = [];
    this.resetSpeedRun();
  }

  getAnchor(): Anchor | null {
    return this.anchor;
  }

  getPending(): PendingPoint[] {
    return [...this.pending];
  }

  private resetSpeedRun(): void {
    this.consecutiveOverSpeed = 0;
    this.overSpeedSince = null;
  }

  private isFiniteNumber(v: unknown): v is number {
    return typeof v === 'number' && Number.isFinite(v);
  }

  /**
   * Process one raw point. Never mutates the raw point.
   */
  validate(raw: RawGpsPoint): ValidatorResult {
    const base = { raw, decision: 'rejected' as PointDecision, reason: null as RejectionReason | null };

    // 1. Coordinate sanity.
    if (
      !this.isFiniteNumber(raw.latitude) ||
      !this.isFiniteNumber(raw.longitude) ||
      Math.abs(raw.latitude) > this.config.maxValidLatitude ||
      Math.abs(raw.longitude) > this.config.maxValidLongitude
    ) {
      return this.finish({ ...base, reason: 'invalid_coordinate' });
    }

    // 2. Timestamp sanity.
    if (!this.isFiniteNumber(raw.timestamp) || raw.timestamp <= 0) {
      return this.finish({ ...base, reason: 'stale_timestamp' });
    }
    if (raw.receivedAt - raw.timestamp > this.config.staleTimestampToleranceMs) {
      return this.finish({ ...base, reason: 'stale_timestamp' });
    }

    // 3. Paused: keep raw, do not accumulate.
    if (this.paused) {
      return this.finish({ ...base, reason: 'paused' });
    }

    // 4. Duplicate / non-increasing timestamp vs anchor.
    if (this.anchor && raw.timestamp <= this.anchor.timestamp) {
      return this.finish({ ...base, reason: 'duplicate_timestamp' });
    }

    // 5. Accuracy bands.
    const accuracy = raw.accuracy;
    if (accuracy === null || !this.isFiniteNumber(accuracy)) {
      // No accuracy info → treat as pending (conservative) unless very tight.
      this.pushPending({ raw, reason: 'poor_accuracy' });
      return this.finish({ ...base, decision: 'pending', reason: 'poor_accuracy' }, false);
    }
    if (accuracy > this.config.pendingAccuracyM) {
      return this.finish({ ...base, reason: 'poor_accuracy' });
    }

    // 6. Gap detection using the anchor timestamp.
    let gapDetected = false;
    if (this.anchor) {
      const gapMs = raw.timestamp - this.anchor.timestamp;
      if (gapMs > this.config.gpsGapThresholdMs) {
        gapDetected = true;
      }
    }

    // 7. Jump / speed checks against anchor (only when we have one and no gap).
    let segmentDistance = 0;
    let impliedSpeed = 0;
    if (this.anchor && !gapDetected) {
      segmentDistance = distanceMeters(this.anchor, raw);
      impliedSpeed = impliedSpeedMps(this.anchor, raw);

      if (
        segmentDistance >= this.config.minJumpDistanceM &&
        impliedSpeed > this.config.maxImpliedSpeedMps
      ) {
        return this.finish(
          { ...base, reason: 'impossible_jump', segmentDistance, impliedSpeed },
          false,
          0,
          false,
          gapDetected,
        );
      }
    }

    // 8. Excessive-speed detection (requirement 6.4) — marker only by default.
    const excessive = this.config.speedFilterEnabled
      ? this.trackSpeed(raw, impliedSpeed)
      : false;

    // 9. Accuracy band: pending vs accepted.
    if (accuracy > this.config.acceptAccuracyM) {
      // 25 < accuracy <= 50 → pending buffer, awaiting confirmation.
      this.pushPending({ raw, reason: 'poor_accuracy' });
      return this.finish(
        { ...base, decision: 'pending', reason: 'poor_accuracy', segmentDistance, impliedSpeed },
        false,
        0,
        false,
        gapDetected,
        excessive,
      );
    }

    // 10. Accepted point.
    const newAnchor = gapDetected || this.anchor === null;
    // Micro-movement gate: displacement under minMovementM is GPS jitter —
    // a phone on a desk drifts 1-3 m per fix, and summing those deltas
    // accumulates phantom distance (random walk). The anchor POSITION stays
    // put so real motion accumulates against it and crosses the threshold
    // promptly; only its timestamp refreshes (fixes ARE arriving, so this
    // is not a GPS gap).
    const micro = !newAnchor && segmentDistance < this.config.minMovementM;
    // On a gap, the first trusted point is ONLY an anchor — do not add distance
    // (requirement 6.3.5-6).
    const addDistance = !newAnchor && !micro;
    const distanceAddedM = addDistance ? segmentDistance : 0;

    if (micro && this.anchor) {
      this.anchor = { ...this.anchor, timestamp: raw.timestamp };
    } else {
      this.anchor = { latitude: raw.latitude, longitude: raw.longitude, timestamp: raw.timestamp };
    }
    this.confirmPendingWithAccepted(raw);

    return this.finish(
      {
        raw,
        decision: 'accepted',
        reason: gapDetected ? 'gps_gap_anchor' : micro ? 'micro_movement' : null,
        segmentDistance: addDistance ? segmentDistance : 0,
        impliedSpeed,
      },
      addDistance,
      distanceAddedM,
      newAnchor,
      gapDetected,
      excessive,
    );
  }

  private trackSpeed(raw: RawGpsPoint, implied: number): boolean {
    const devSpeed = raw.speed;
    // Use the worse of device speed and implied speed for detection.
    const candidate =
      devSpeed !== null && Number.isFinite(devSpeed)
        ? Math.max(devSpeed, implied)
        : implied;

    this.speedWindow.push({
      latitude: raw.latitude,
      longitude: raw.longitude,
      timestamp: raw.timestamp,
      deviceSpeed: devSpeed,
    });
    if (this.speedWindow.length > 12) {
      this.speedWindow.shift();
    }

    if (candidate > this.config.speedThresholdMps) {
      this.consecutiveOverSpeed += 1;
      if (this.overSpeedSince === null) {
        this.overSpeedSince = raw.timestamp;
      }
    } else {
      this.resetSpeedRun();
    }

    const byCount =
      this.consecutiveOverSpeed >= this.config.excessiveSpeedConsecutivePoints;
    const byDuration =
      this.overSpeedSince !== null &&
      raw.timestamp - this.overSpeedSince >= this.config.excessiveSpeedSustainMs;

    return byCount || byDuration;
  }

  private pushPending(p: PendingPoint): void {
    this.pending.push(p);
    if (this.pending.length > this.config.maxPendingBuffer) {
      this.pending.shift();
    }
  }

  /**
   * When a good point is accepted, decide what happens to buffered pending
   * points: those consistent with the new trajectory get promoted to accepted
   * (they will be re-evaluated by the caller via their stored segment); those
   * that are clearly off get dropped. For the POC we keep pending points in
   * the buffer for the map to render as pending, and clear ones older than the
   * gap threshold. Full promotion logic is exercised in unit tests.
   */
  private confirmPendingWithAccepted(accepted: RawGpsPoint): void {
    const keep: PendingPoint[] = [];
    for (const p of this.pending) {
      const d = distanceMeters(accepted, p.raw);
      // Keep pending points that are near the accepted trajectory.
      if (d <= this.config.pendingAccuracyM * 2) {
        keep.push(p);
      }
    }
    this.pending = keep;
  }

  private finish(
    point: ValidatedPoint,
    addedDistance = false,
    distanceAddedM = 0,
    newAnchor = false,
    gapDetected = false,
    excessiveSpeedDetected = false,
  ): ValidatorResult {
    return {
      point,
      addedDistance,
      distanceAddedM,
      newAnchor,
      gapDetected,
      excessiveSpeedDetected,
    };
  }
}
