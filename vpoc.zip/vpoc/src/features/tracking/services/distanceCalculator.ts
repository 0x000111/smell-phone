/**
 * Distance calculation built on the `haversine` package (requirement 3.1).
 * Only accepted points ever contribute to validated distance
 * (requirement 2.4 / 5.3).
 */
import haversine from 'haversine';

export interface LatLng {
  latitude: number;
  longitude: number;
}

/** Great-circle distance in metres between two coordinates. */
export function distanceMeters(a: LatLng, b: LatLng): number {
  // haversine default format passes {latitude, longitude} through unchanged.
  return haversine(
    { latitude: a.latitude, longitude: a.longitude },
    { latitude: b.latitude, longitude: b.longitude },
    { unit: 'meter' },
  ) as number;
}

/**
 * Raw cumulative distance over a sequence of points (diagnostic only —
 * includes jitter/drift; never used for validated mileage).
 */
export function rawCumulativeDistance(points: LatLng[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i++) {
    total += distanceMeters(points[i - 1], points[i]);
  }
  return total;
}

/**
 * Implied speed (m/s) between two fixes. Returns 0 for non-positive dt so
 * callers must treat duplicate timestamps separately.
 */
export function impliedSpeedMps(
  a: LatLng & { timestamp: number },
  b: LatLng & { timestamp: number },
): number {
  const dtS = (b.timestamp - a.timestamp) / 1000;
  if (dtS <= 0) {
    return 0;
  }
  return distanceMeters(a, b) / dtS;
}

/** Short-window average speed (m/s) over the last `windowMs` of fixes. */
export function windowAverageSpeedMps(
  points: Array<LatLng & { timestamp: number }>,
  windowMs: number,
): number | null {
  if (points.length < 2) {
    return null;
  }
  const last = points[points.length - 1];
  const windowStart = last.timestamp - windowMs;
  const inWindow = points.filter(p => p.timestamp >= windowStart);
  if (inWindow.length < 2) {
    return null;
  }
  const first = inWindow[0];
  const dtS = (last.timestamp - first.timestamp) / 1000;
  if (dtS <= 0) {
    return null;
  }
  let dist = 0;
  for (let i = 1; i < inWindow.length; i++) {
    dist += distanceMeters(inWindow[i - 1], inWindow[i]);
  }
  return dist / dtS;
}
