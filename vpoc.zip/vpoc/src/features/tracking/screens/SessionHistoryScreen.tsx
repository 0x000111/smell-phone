/**
 * Session history list (requirement 9.3) — read-only summaries of completed
 * sessions, tap to open the detail replay.
 */
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppSelector } from '../../../app/store/hooks';
import { SAMPLING_PROFILES } from '../config/samplingConfigs';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../../app/navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'History'>;

function fmtDur(ms: number): string {
  const s = Math.floor(ms / 1000);
  const m = Math.floor((s % 3600) / 60);
  const h = Math.floor(s / 3600);
  return h > 0 ? `${h}h ${m}m` : `${m}m ${s % 60}s`;
}

function fmtDist(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`;
}

export default function SessionHistoryScreen({ navigation }: Props) {
  const history = useAppSelector(s => s.tracking.history);

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ Back</Text>
        </Pressable>
        <Text style={styles.title}>Session History</Text>
        <View style={styles.spacer} />
      </View>
      <ScrollView contentContainerStyle={styles.scroll}>
        {history.length === 0 ? (
          <Text style={styles.empty}>No completed sessions yet.</Text>
        ) : (
          history.map(item => (
            <Pressable
              key={item.id}
              style={styles.card}
              onPress={() => navigation.navigate('SessionDetail', { sessionId: item.id })}
            >
              <Text style={styles.cardTitle}>
                {new Date(item.startedAt).toLocaleString()}
              </Text>
              <Text style={styles.cardMeta}>
                {item.state} · {SAMPLING_PROFILES[item.samplingConfigId].label}
              </Text>
              <View style={styles.cardRow}>
                <Text style={styles.cardStat}>Validated: {fmtDist(item.validatedDistanceM)}</Text>
                <Text style={styles.cardStat}>Raw: {fmtDist(item.rawDistanceM)}</Text>
              </View>
              <View style={styles.cardRow}>
                <Text style={styles.cardStat}>Active: {fmtDur(item.activeDurationMs)}</Text>
                <Text style={styles.cardStat}>Paused: {fmtDur(item.pauseDurationMs)}</Text>
              </View>
              <View style={styles.cardRow}>
                <Text style={styles.cardStat}>Accepted: {item.acceptedCount}</Text>
                <Text style={styles.cardStat}>Rejected: {item.rejectedCount}</Text>
              </View>
            </Pressable>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0d1117' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 24,
  },
  back: { color: '#2b7cff', fontSize: 16, width: 60 },
  spacer: { width: 60 },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  scroll: { padding: 16 },
  empty: { color: '#9aa4b8', textAlign: 'center', marginTop: 40 },
  card: {
    backgroundColor: '#161b22',
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
  },
  cardTitle: { color: '#fff', fontSize: 15, fontWeight: '700' },
  cardMeta: { color: '#9aa4b8', fontSize: 12, marginTop: 2, marginBottom: 8 },
  cardRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  cardStat: { color: '#cfd6e4', fontSize: 13 },
});
