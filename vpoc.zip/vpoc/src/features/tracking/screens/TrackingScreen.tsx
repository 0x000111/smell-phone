/**
 * Tracking screen (requirement 9.1).
 * Map + stats overlay + controls (Start/Pause/Resume/Stop), sampling-config
 * selector, follow toggle, debug toggle, and the unfinished-session restore
 * banner (requirement 8).
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Linking,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {
  SafeAreaView,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from '../../../app/store/hooks';
import { trackingEngine } from '../services/trackingEngine';
import { sessionPersistence } from '../services/sessionPersistence';
import { SAMPLING_PROFILES, type SamplingConfigId } from '../config/samplingConfigs';
import {
  completeSession,
  endSession,
  restoreSession,
  setSamplingConfig,
} from '../store/trackingSlice';
import TrackMap from '../components/TrackMap';
import StatsBar from '../components/StatsBar';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../../app/navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Tracking'>;

export default function TrackingScreen({ navigation }: Props) {
  const dispatch = useAppDispatch();
  const insets = useSafeAreaInsets();
  const session = useAppSelector(s => s.tracking.session);
  const [debugMode, setDebugMode] = useState(false);
  const [follow, setFollow] = useState(true);
  const [busy, setBusy] = useState(false);
  const [restoreCandidate, setRestoreCandidate] = useState(false);
  const [, forceTick] = useState(0);

  const state = session?.state ?? 'idle';
  const running = state === 'active_good_signal' || state === 'active_weak_signal';
  const resuming = state === 'resuming';
  const paused = state === 'paused';
  const starting = state === 'starting';
  const active = session !== null && state !== 'completed';

  // Ref so timers always see the freshest session without re-subscribing.
  const sessionRef = useRef(session);
  sessionRef.current = session;
  const sessionId = session?.id ?? null;
  const hasActiveSince = session !== null && session.activeSince !== null;

  // Live timer tick (duration display only — actual accumulation is in the
  // reducer, driven by pause/resume timestamps).
  useEffect(() => {
    if (!hasActiveSince) return;
    const id = setInterval(() => {
      forceTick(t => t + 1);
    }, 1000);
    return () => clearInterval(id);
  }, [hasActiveSince]);

  // Throttled incremental persistence (requirement 8).
  useEffect(() => {
    if (!sessionId) return;
    const id = setInterval(() => {
      const s = sessionRef.current;
      if (s) {
        sessionPersistence.scheduleSave(s);
      }
    }, 5000);
    return () => clearInterval(id);
  }, [sessionId]);

  // Check for unfinished session on mount (requirement 8 / app restart).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { found, session: saved } = await sessionPersistence.loadActive();
      if (!cancelled && found && saved && !sessionRef.current) {
        setRestoreCandidate(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const activeDurationMs = (() => {
    if (!session) return 0;
    if (session.activeSince !== null) {
      return session.accumulatedActiveDurationMs + (Date.now() - session.activeSince);
    }
    return session.accumulatedActiveDurationMs;
  })();

  const handleStart = useCallback(
    async (configId: SamplingConfigId) => {
      setBusy(true);
      const res = await trackingEngine.start(configId);
      if (!res.ok) {
        const isPermission = res.error.startsWith('permission');
        Alert.alert(
          isPermission ? 'Location permission needed' : 'Cannot start tracking',
          isPermission
            ? 'Go to system Settings → Apps → GPS Walk POC → Permissions → Location and set it to "Allow". On Xiaomi also make sure the system Location (定位服务) switch is ON in quick settings.'
            : `Engine error: ${res.error}`,
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Open Settings',
              onPress: () => {
                Linking.openSettings().catch(() => {});
              },
            },
          ],
        );
      }
      setBusy(false);
    },
    [],
  );

  const handlePause = useCallback(() => {
    trackingEngine.pause();
    if (session) {
      sessionPersistence.saveNow(session).catch(() => {});
    }
  }, [session]);

  const handleResume = useCallback(() => {
    trackingEngine.resume();
  }, []);

  const confirmStop = useCallback(() => {
    Alert.alert('Stop tracking?', 'The session summary will be saved locally.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Stop',
        style: 'destructive',
        onPress: async () => {
          setBusy(true);
          await trackingEngine.stop();
          await sessionPersistence.clearActive();
          setBusy(false);
        },
      },
    ]);
  }, []);

  const handleRestore = useCallback(async () => {
    const { session: saved } = await sessionPersistence.loadActive();
    if (!saved) {
      setRestoreCandidate(false);
      return;
    }
    dispatch(restoreSession({ session: saved }));
    setRestoreCandidate(false);
    // Resume keeps the saved distance; the next trusted point re-anchors.
    const res = await trackingEngine.resumeRestoredSession(saved.samplingConfigId);
    if (!res.ok) {
      Alert.alert(
        'Cannot resume',
        res.error.startsWith('permission')
          ? 'Location permission was denied. Enable it in system Settings, then retry.'
          : `Engine error: ${res.error}`,
      );
    }
  }, [dispatch]);

  const handleDiscard = useCallback(async () => {
    // "End & save": load the persisted session, mark it interrupted and
    // move it to history — do NOT throw away the recorded distance.
    const { session: saved } = await sessionPersistence.loadActive();
    if (saved) {
      dispatch(restoreSession({ session: saved }));
      dispatch(endSession({ now: Date.now(), interrupted: true }));
      dispatch(completeSession({ now: Date.now() }));
    }
    await sessionPersistence.clearActive();
    setRestoreCandidate(false);
  }, [dispatch]);

  const changeConfig = useCallback(
    (id: SamplingConfigId) => {
      if (session) {
        dispatch(setSamplingConfig({ configId: id }));
        // Restart the watch with the new profile if currently running.
        if (running || starting || paused) {
          trackingEngine
            .stop()
            .then(() => trackingEngine.start(id))
            .catch(() => {});
        }
      }
    },
    [dispatch, session, running, starting, paused],
  );

  const [configPickerVisible, setConfigPickerVisible] = useState(false);
  const [moreMenuVisible, setMoreMenuVisible] = useState(false);
  const currentConfigId: SamplingConfigId = session?.samplingConfigId ?? 'balanced';

  // Absolute-positioned overlays ignore SafeAreaView padding, so every
  // floating element is offset by the real inset on this device.
  const topBarTop = insets.top + 8;
  const statsTop = topBarTop + 52;
  // Restore banner only shows when there is no session (no StatsBar), so it
  // can sit directly under the top bar.
  const bannerTop = topBarTop + 60;
  const controlsBottom = insets.bottom + 24;
  const followBottom = controlsBottom + 76;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <TrackMap
        session={session}
        debugMode={debugMode}
        followUser={follow && active}
        onUserGesture={() => setFollow(false)}
      />

      {/* Top bar: history, sampling config, more */}
      <View style={[styles.topBar, { top: topBarTop }]}>
        <Pressable style={styles.iconBtn} onPress={() => navigation.navigate('History')}>
          <Text style={styles.iconBtnText}>☰</Text>
        </Pressable>
        <Pressable
          style={styles.configChip}
          onPress={() => setConfigPickerVisible(true)}
        >
          <Text style={styles.configChipText}>{SAMPLING_PROFILES[currentConfigId].label}</Text>
        </Pressable>
        <Pressable
          style={[styles.iconBtn, debugMode && styles.iconBtnActive]}
          onPress={() => setMoreMenuVisible(true)}
        >
          <Text style={styles.iconBtnText}>⋯</Text>
        </Pressable>
      </View>

      {/* Stats */}
      {session ? (
        <StatsBar
          top={statsTop}
          distanceM={session.validatedDistanceM}
          activeDurationMs={activeDurationMs}
          signal={session.signalLevel}
          state={session.state}
          accuracy={session.lastAcceptedPoint?.accuracy ?? session.rawPoints[session.rawPoints.length - 1]?.accuracy ?? null}
          speedMps={session.lastAcceptedPoint?.speed ?? null}
          lastError={session.lastError}
        />
      ) : null}

      {/* Restore banner */}
      {restoreCandidate && !session ? (
        <View style={[styles.restoreBanner, { top: bannerTop }]}>
          <Text style={styles.restoreText}>Unfinished session found from a previous run.</Text>
          <View style={styles.restoreBtns}>
            <Pressable style={styles.restoreBtn} onPress={handleRestore}>
              <Text style={styles.restoreBtnText}>Resume</Text>
            </Pressable>
            <Pressable style={styles.discardBtn} onPress={handleDiscard}>
              <Text style={styles.discardBtnText}>End & save</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {/* Follow toggle */}
      {session ? (
        <Pressable
          style={[styles.followBtn, { bottom: followBottom }, follow && styles.followBtnActive]}
          onPress={() => setFollow(f => !f)}
        >
          <Text style={styles.followText}>{follow ? '🎯 Follow ON' : '🎯 Follow OFF'}</Text>
        </Pressable>
      ) : null}

      {/* Controls */}
      <View style={[styles.controls, { bottom: controlsBottom }]}>
        {busy ? (
          <ActivityIndicator size="large" color="#2b7cff" />
        ) : !active ? (
          <Pressable style={[styles.bigBtn, styles.startBtn]} onPress={() => handleStart(currentConfigId)}>
            <Text style={styles.bigBtnText}>▶ Start</Text>
          </Pressable>
        ) : (
          <>
            {running || starting || resuming ? (
              <Pressable style={[styles.bigBtn, styles.pauseBtn]} onPress={handlePause}>
                <Text style={styles.bigBtnText}>⏸ Pause</Text>
              </Pressable>
            ) : null}
            {paused || resuming ? (
              <Pressable style={[styles.bigBtn, styles.resumeBtn]} onPress={handleResume}>
                <Text style={styles.bigBtnText}>⏵ Resume</Text>
              </Pressable>
            ) : null}
            <Pressable style={[styles.bigBtn, styles.stopBtn]} onPress={confirmStop}>
              <Text style={styles.bigBtnText}>■ Stop</Text>
            </Pressable>
          </>
        )}
      </View>

      {/* Config picker */}
      <Modal visible={configPickerVisible} transparent animationType="fade">
        <Pressable style={styles.modalBackdrop} onPress={() => setConfigPickerVisible(false)}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Sampling configuration</Text>
            {(Object.values(SAMPLING_PROFILES)).map(p => (
              <Pressable
                key={p.id}
                style={[styles.modalOption, p.id === currentConfigId && styles.modalOptionActive]}
                onPress={() => {
                  changeConfig(p.id);
                  setConfigPickerVisible(false);
                }}
              >
                <Text style={styles.modalOptionLabel}>{p.label}</Text>
                <Text style={styles.modalOptionDesc}>{p.description}</Text>
              </Pressable>
            ))}
            <Text style={styles.modalHint}>
              Changing the config restarts the location watch.
            </Text>
          </View>
        </Pressable>
      </Modal>

      {/* More menu */}
      <Modal visible={moreMenuVisible} transparent animationType="fade">
        <Pressable style={styles.modalBackdrop} onPress={() => setMoreMenuVisible(false)}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>More</Text>
            <Pressable
              style={[styles.modalOption, debugMode && styles.modalOptionActive]}
              onPress={() => setDebugMode(d => !d)}
            >
              <Text style={styles.modalOptionLabel}>
                Debug overlay {debugMode ? '(ON)' : '(OFF)'}
              </Text>
              <Text style={styles.modalOptionDesc}>
                Show raw track, pending and rejected points on the map.
              </Text>
            </Pressable>
            <Pressable
              style={styles.modalOption}
              onPress={() => {
                setMoreMenuVisible(false);
                navigation.navigate('Diagnostics');
              }}
            >
              <Text style={styles.modalOptionLabel}>Diagnostics</Text>
              <Text style={styles.modalOptionDesc}>
                Point counts, accuracy stats, gaps, JSON export.
              </Text>
            </Pressable>
            <Pressable
              style={styles.modalOption}
              onPress={() => {
                setMoreMenuVisible(false);
                navigation.navigate('Settings');
              }}
            >
              <Text style={styles.modalOptionLabel}>Filter settings</Text>
              <Text style={styles.modalOptionDesc}>
                Thresholds and business-decision switches.
              </Text>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0d1117' },
  topBar: {
    position: 'absolute',
    top: 8,
    left: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  iconBtn: {
    backgroundColor: 'rgba(20,24,35,0.85)',
    borderRadius: 10,
    padding: 10,
  },
  iconBtnActive: { backgroundColor: '#2b7cff' },
  iconBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  configChip: {
    backgroundColor: 'rgba(20,24,35,0.85)',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    flex: 1,
    marginHorizontal: 8,
    alignItems: 'center',
  },
  configChipText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  followBtn: {
    position: 'absolute',
    right: 12,
    bottom: 120,
    backgroundColor: 'rgba(20,24,35,0.85)',
    borderRadius: 10,
    padding: 10,
  },
  followBtnActive: { backgroundColor: 'rgba(43,124,255,0.9)' },
  followText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  restoreBanner: {
    position: 'absolute',
    top: 150,
    left: 16,
    right: 16,
    backgroundColor: 'rgba(241,196,15,0.95)',
    borderRadius: 12,
    padding: 14,
  },
  restoreText: { color: '#2c2405', fontSize: 13, fontWeight: '600', marginBottom: 10 },
  restoreBtns: { flexDirection: 'row', gap: 10 },
  restoreBtn: { backgroundColor: '#2b7cff', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 8 },
  restoreBtnText: { color: '#fff', fontWeight: '700' },
  discardBtn: { backgroundColor: '#c0392b', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 8 },
  discardBtnText: { color: '#fff', fontWeight: '700' },
  controls: {
    position: 'absolute',
    bottom: 24,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
  },
  bigBtn: {
    flex: 1,
    maxWidth: 160,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  startBtn: { backgroundColor: '#27ae60' },
  pauseBtn: { backgroundColor: '#f39c12' },
  resumeBtn: { backgroundColor: '#2b7cff' },
  stopBtn: { backgroundColor: '#c0392b' },
  bigBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', padding: 24 },
  modalCard: { backgroundColor: '#1a1f2e', borderRadius: 16, padding: 18 },
  modalTitle: { color: '#fff', fontSize: 16, fontWeight: '700', marginBottom: 12 },
  modalOption: {
    padding: 12,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  modalOptionActive: { backgroundColor: 'rgba(43,124,255,0.25)' },
  modalOptionLabel: { color: '#fff', fontWeight: '700', fontSize: 14 },
  modalOptionDesc: { color: '#9aa4b8', fontSize: 12, marginTop: 2 },
  modalHint: { color: '#667', fontSize: 11, marginTop: 6 },
});
