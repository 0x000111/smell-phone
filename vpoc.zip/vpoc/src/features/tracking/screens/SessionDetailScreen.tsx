/**
 * Read-only replay of a completed session: map + summary (requirement 9.3).
 */
import React, { useMemo } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { useAppSelector } from '../../../app/store/hooks';
import { groupBySegment, toDisplayPoints } from '../utils/trackSimplification';
import { hasMapsKey } from '../config/mapsConfig';
import { SAMPLING_PROFILES } from '../config/samplingConfigs';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../../app/navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'SessionDetail'>;

export default function SessionDetailScreen({ route, navigation }: Props) {
  const history = useAppSelector(s => s.tracking.history);
  const item = history.find(h => h.id === route.params.sessionId);

  const segments = useMemo(() => {
    if (!item) return [];
    return groupBySegment(toDisplayPoints(item.session.validatedPoints, item.session.segmentBoundaries));
  }, [item]);

  if (!item) {
    return (
      <SafeAreaView style={styles.safe}>
        <Text style={styles.empty}>Session not found.</Text>
      </SafeAreaView>
    );
  }

  const s = item.session;
  const first = s.validatedPoints.find(p => p.decision === 'accepted');
  const initialRegion = first
    ? {
        latitude: first.raw.latitude,
        longitude: first.raw.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      }
    : undefined;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <Text style={styles.back} onPress={() => navigation.goBack()}>
          ‹ Back
        </Text>
        <Text style={styles.title}>Session replay</Text>
        <View style={styles.spacer} />
      </View>
      <View style={styles.mapWrap}>
        {hasMapsKey() && initialRegion ? (
          <MapView
            provider={PROVIDER_GOOGLE}
            style={StyleSheet.absoluteFill}
            initialRegion={initialRegion}
          >
            {segments.map((seg, i) => (
              <Polyline key={i} coordinates={seg} strokeColor="#2b7cff" strokeWidth={4} />
            ))}
          </MapView>
        ) : (
          <View style={styles.noKey}>
            <Text style={styles.noKeyText}>
              {hasMapsKey() ? 'No track data to display.' : 'Maps key not configured.'}
            </Text>
          </View>
        )}
      </View>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.meta}>{new Date(item.startedAt).toLocaleString()}</Text>
        <Text style={styles.meta}>State: {item.state} · {SAMPLING_PROFILES[item.samplingConfigId].label}</Text>
        <Row label="Validated distance" value={`${item.validatedDistanceM.toFixed(1)} m`} />
        <Row label="Raw distance" value={`${item.rawDistanceM.toFixed(1)} m`} />
        <Row label="Active duration" value={`${Math.round(item.activeDurationMs / 1000)} s`} />
        <Row label="Pause duration" value={`${Math.round(item.pauseDurationMs / 1000)} s`} />
        <Row label="Accepted points" value={String(item.acceptedCount)} />
        <Row label="Rejected points" value={String(item.rejectedCount)} />
        <Row label="GPS gaps" value={String(s.stats.gpsGapCount)} />
        <Row label="Longest gap" value={`${Math.round(s.stats.longestGapMs / 1000)} s`} />
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0d1117' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 24 },
  back: { color: '#2b7cff', fontSize: 16, width: 60 },
  spacer: { width: 60 },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  mapWrap: { height: 260, margin: 16, borderRadius: 12, overflow: 'hidden', backgroundColor: '#161b22' },
  noKey: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  noKeyText: { color: '#9aa4b8' },
  scroll: { padding: 16 },
  meta: { color: '#9aa4b8', fontSize: 13, marginBottom: 6 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#1c2330' },
  rowLabel: { color: '#cfd6e4' },
  rowValue: { color: '#fff', fontWeight: '600' },
  empty: { color: '#9aa4b8', padding: 40, textAlign: 'center' },
});
