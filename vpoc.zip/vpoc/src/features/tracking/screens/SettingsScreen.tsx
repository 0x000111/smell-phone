/**
 * Settings screen — exposes the business decisions that should NOT be
 * hard-coded (requirement 16) as switches, and shows the centralised filter
 * thresholds so they can be tuned after real-device testing.
 *
 * Changes here mutate the live engine's FilterConfig.
 */
import React, { useState } from 'react';
import { ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DEFAULT_FILTER_CONFIG, type FilterConfig } from '../config/filterConfig';
import { trackingEngine } from '../services/trackingEngine';

export default function SettingsScreen() {
  const [cfg, setCfg] = useState<FilterConfig>({ ...DEFAULT_FILTER_CONFIG });

  const update = (patch: Partial<FilterConfig>) => {
    const next = { ...cfg, ...patch };
    setCfg(next);
    trackingEngine.setFilterConfig(next);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <Text style={styles.title}>Filter & business switches</Text>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.hint}>
          Thresholds are POC defaults. Adjust after real-device testing — they
          live in config/filterConfig.ts, not in components.
        </Text>

        <Group title="Accuracy bands (metres)">
          <Line label="Accept ≤" value={cfg.acceptAccuracyM} />
          <Line label="Pending ≤" value={cfg.pendingAccuracyM} />
          <Line label="Pending confirm count" value={cfg.pendingConfirmCount} />
        </Group>

        <Group title="GPS gap">
          <Line label="Gap threshold (s)" value={cfg.gpsGapThresholdMs / 1000} />
          <Line label="No-signal after (s)" value={cfg.noSignalAfterMs / 1000} />
          <Line label="Min movement (m)" value={cfg.minMovementM} />
        </Group>

        <Group title="Speed rules (business decision #2/#3)">
          <SwitchRow
            label="Speed filtering enabled"
            value={cfg.speedFilterEnabled}
            onValueChange={v => update({ speedFilterEnabled: v })}
          />
          <Line label="Threshold (km/h)" value={+(cfg.speedThresholdMps * 3.6).toFixed(1)} />
          <Line label="Consecutive points" value={cfg.excessiveSpeedConsecutivePoints} />
          <SwitchRow
            label="End session on excessive speed"
            value={cfg.endSessionOnExcessiveSpeed}
            onValueChange={v => update({ endSessionOnExcessiveSpeed: v })}
          />
          <Text style={styles.note}>
            Default: only reject the segment, keep prior distance (business
            decision #3 unresolved).
          </Text>
        </Group>

        <Group title="Pause (business decision #5/#6)">
          <Text style={styles.note}>
            Manual Pause/Resume implemented. Pause time is NOT counted in
            active duration. Auto idle-pause is disabled (experiment only).
          </Text>
          <SwitchRow
            label="Idle detection (experiment)"
            value={cfg.idleDetectionEnabled}
            onValueChange={v => update({ idleDetectionEnabled: v })}
          />
        </Group>

        <Group title="Jump sanity">
          <Line label="Max implied speed (km/h)" value={+(cfg.maxImpliedSpeedMps * 3.6).toFixed(0)} />
          <Line label="Min jump distance (m)" value={cfg.minJumpDistanceM} />
        </Group>

        <Group title="Android location provider">
          <SwitchRow
            label="Force raw GPS (LocationManager)"
            value={cfg.forceLocationManager}
            onValueChange={v => update({ forceLocationManager: v })}
          />
          <Text style={styles.note}>
            Off (default): Google Play Services fused provider with cell/WiFi
            fallback — works indoors and in urban canyons. On: raw GPS only
            (GPS_PROVIDER) for honest raw-signal testing; may yield no fix
            when satellites are blocked. Restart tracking after changing.
          </Text>
        </Group>
      </ScrollView>
    </SafeAreaView>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.group}>
      <Text style={styles.groupTitle}>{title}</Text>
      {children}
    </View>
  );
}

function Line({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.line}>
      <Text style={styles.lineLabel}>{label}</Text>
      <Text style={styles.lineValue}>{value}</Text>
    </View>
  );
}

function SwitchRow({
  label,
  value,
  onValueChange,
}: {
  label: string;
  value: boolean;
  onValueChange: (v: boolean) => void;
}) {
  return (
    <View style={styles.line}>
      <Text style={styles.lineLabel}>{label}</Text>
      <Switch value={value} onValueChange={onValueChange} />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0d1117' },
  title: { color: '#fff', fontSize: 20, fontWeight: '700', padding: 16, paddingTop: 24 },
  scroll: { padding: 16 },
  hint: { color: '#9aa4b8', fontSize: 12, marginBottom: 16, lineHeight: 18 },
  group: { backgroundColor: '#161b22', borderRadius: 12, padding: 14, marginBottom: 14 },
  groupTitle: { color: '#2b7cff', fontSize: 13, fontWeight: '700', marginBottom: 10, textTransform: 'uppercase' },
  line: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 6 },
  lineLabel: { color: '#cfd6e4', fontSize: 14 },
  lineValue: { color: '#fff', fontSize: 14, fontWeight: '600' },
  note: { color: '#667', fontSize: 11, marginTop: 6, lineHeight: 16 },
});
