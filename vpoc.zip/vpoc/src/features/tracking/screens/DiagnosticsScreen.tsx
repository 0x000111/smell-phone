/**
 * Diagnostics screen (requirement 9.2).
 *
 * Shows raw/accepted/pending/rejected counts, rejection-reason breakdown,
 * accuracy stats (mean + P95), actual callback interval stats, GPS gap count
 * and longest gap, raw vs validated distance, accepted/rejected segment
 * counts, speed info, app-state transitions, event timeline, and a local JSON
 * export of the current session.
 */
import React, { useCallback, useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppSelector } from '../../../app/store/hooks';
import type { SessionStats } from '../types/session';
import { exportSessionDiagnostics } from '../services/exportService';

function p95(sortedAsc: number[]): number | null {
  if (sortedAsc.length === 0) return null;
  const idx = Math.min(sortedAsc.length - 1, Math.floor(0.95 * (sortedAsc.length - 1)));
  return sortedAsc[idx];
}

function mean(values: number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function fmt(n: number | null, digits = 1): string {
  return n === null ? '--' : n.toFixed(digits);
}

function fmtDur(ms: number | null): string {
  if (ms === null) return '--';
  const s = Math.round(ms / 1000);
  return s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`;
}

function StatRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

export default function DiagnosticsScreen() {
  const session = useAppSelector(s => s.tracking.session);
  const [exporting, setExporting] = useState(false);

  const derived = useMemo(() => {
    const stats: SessionStats | null = session?.stats ?? null;
    if (!stats) return null;
    const sortedAcc = [...stats.acceptedAccuracies].sort((a, b) => a - b);
    const sortedInt = [...stats.callbackIntervalsMs].sort((a, b) => a - b);
    return {
      meanAcc: mean(sortedAcc),
      p95Acc: p95(sortedAcc),
      meanInterval: mean(sortedInt),
      p95Interval: p95(sortedInt),
    };
  }, [session]);

  const doExport = useCallback(async () => {
    if (!session) return;
    setExporting(true);
    const res = await exportSessionDiagnostics(session);
    setExporting(false);
    Alert.alert(
      res.ok ? 'Exported' : 'Export failed',
      res.path ?? res.error ?? 'Unknown result',
    );
  }, [session]);

  if (!session) {
    return (
      <SafeAreaView style={styles.safe}>
        <Header />
        <View style={styles.empty}>
          <Text style={styles.emptyText}>No active session to diagnose.</Text>
        </View>
      </SafeAreaView>
    );
  }

  const s = session.stats;

  return (
    <SafeAreaView style={styles.safe}>
      <Header />
      <ScrollView contentContainerStyle={styles.scroll}>
        <Section title="Point counts">
          <StatRow label="Raw" value={String(s.rawCount)} />
          <StatRow label="Accepted" value={String(s.acceptedCount)} />
          <StatRow label="Pending" value={String(s.pendingCount)} />
          <StatRow label="Rejected" value={String(s.rejectedCount)} />
        </Section>

        <Section title="Distance">
          <StatRow label="Raw cumulative" value={`${fmt(session.rawDistanceM, 1)} m`} />
          <StatRow label="Validated" value={`${fmt(session.validatedDistanceM, 1)} m`} />
          <StatRow label="Accepted segments" value={String(s.acceptedSegments)} />
          <StatRow label="Rejected segments" value={String(s.rejectedSegments)} />
          <StatRow label="Excessive-speed segments" value={String(s.excessiveSpeedSegments)} />
        </Section>

        <Section title="Accuracy">
          <StatRow label="Mean (accepted)" value={derived ? `${fmt(derived.meanAcc)} m` : '--'} />
          <StatRow label="P95 (accepted)" value={derived ? `${fmt(derived.p95Acc)} m` : '--'} />
        </Section>

        <Section title="Callback interval (actual)">
          <StatRow label="Mean" value={derived ? fmtDur(derived.meanInterval) : '--'} />
          <StatRow label="P95" value={derived ? fmtDur(derived.p95Interval) : '--'} />
          <StatRow
            label="Target (configured)"
            value={fmtDur(
              session.samplingConfigId === 'high'
                ? 2500
                : session.samplingConfigId === 'balanced'
                  ? 5000
                  : 10000,
            )}
          />
        </Section>

        <Section title="GPS gaps">
          <StatRow label="Gap count" value={String(s.gpsGapCount)} />
          <StatRow label="Longest gap" value={fmtDur(s.longestGapMs)} />
        </Section>

        <Section title="Rejection reasons">
          {Object.keys(s.rejectionReasons).length === 0 ? (
            <Text style={styles.rowValue}>none</Text>
          ) : (
            Object.entries(s.rejectionReasons).map(([k, v]) => (
              <StatRow key={k} label={k} value={String(v)} />
            ))
          )}
        </Section>

        <Section title="Points by app state">
          {Object.entries(s.pointsByAppState).map(([k, v]) => (
            <StatRow key={k} label={k} value={String(v)} />
          ))}
        </Section>

        <Section title="Event timeline">
          {session.events.slice(-40).reverse().map((ev, i) => (
            <Text key={i} style={styles.event}>
              {new Date(ev.at).toLocaleTimeString()} — {ev.type}
              {ev.detail ? ` (${ev.detail})` : ''}
            </Text>
          ))}
        </Section>

        <Pressable
          style={[styles.exportBtn, exporting && styles.exportBtnDisabled]}
          onPress={doExport}
          disabled={exporting}
        >
          <Text style={styles.exportText}>
            {exporting ? 'Exporting…' : 'Export session JSON (local)'}
          </Text>
        </Pressable>
        <Text style={styles.exportHint}>
          Saved on-device only. Never uploaded to any external service.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>Diagnostics</Text>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0d1117' },
  header: { padding: 16, paddingTop: 24 },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: '700' },
  scroll: { padding: 16, paddingBottom: 40 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { color: '#9aa4b8' },
  section: {
    backgroundColor: '#161b22',
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
  },
  sectionTitle: { color: '#2b7cff', fontSize: 13, fontWeight: '700', marginBottom: 10, textTransform: 'uppercase' },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  rowLabel: { color: '#cfd6e4', fontSize: 14 },
  rowValue: { color: '#fff', fontSize: 14, fontWeight: '600' },
  event: { color: '#9aa4b8', fontSize: 12, paddingVertical: 2 },
  exportBtn: {
    backgroundColor: '#27ae60',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  exportBtnDisabled: { opacity: 0.6 },
  exportText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  exportHint: { color: '#667', fontSize: 11, marginTop: 8, textAlign: 'center' },
});
