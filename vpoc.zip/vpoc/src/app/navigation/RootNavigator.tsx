import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TrackingScreen from '../../features/tracking/screens/TrackingScreen';
import DiagnosticsScreen from '../../features/tracking/screens/DiagnosticsScreen';
import SessionHistoryScreen from '../../features/tracking/screens/SessionHistoryScreen';
import SessionDetailScreen from '../../features/tracking/screens/SessionDetailScreen';
import SettingsScreen from '../../features/tracking/screens/SettingsScreen';

export type RootStackParamList = {
  Tracking: undefined;
  Diagnostics: undefined;
  History: undefined;
  SessionDetail: { sessionId: string };
  Settings: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Tracking" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Tracking" component={TrackingScreen} />
        <Stack.Screen name="Diagnostics" component={DiagnosticsScreen} />
        <Stack.Screen name="History" component={SessionHistoryScreen} />
        <Stack.Screen name="SessionDetail" component={SessionDetailScreen} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
