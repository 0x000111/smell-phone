import { configureStore, combineReducers, type Reducer, type UnknownAction } from '@reduxjs/toolkit';
import {
  persistStore,
  persistReducer,
  createTransform,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';
import trackingReducer from '../../features/tracking/store/trackingSlice';
import type { TrackingState } from '../../features/tracking/store/trackingSlice';

const rootReducer = combineReducers({
  tracking: trackingReducer,
});

/**
 * Do NOT persist the in-flight session through redux-persist: the live
 * session is owned by sessionPersistence (throttled writes to its own key).
 * Persisting it twice caused a killed app to rehydrate a "running" session
 * on next launch, bypassing the restore banner and freezing the UI in
 * Pause/Stop state. History (completed sessions) is still persisted.
 *
 * Strips on BOTH directions: the read side also sanitises old storage
 * written before this fix, so an already-installed app upgrades cleanly.
 */
const stripLiveSession = createTransform(
  (inboundState: TrackingState) => ({
    ...inboundState,
    session: null,
    dirtySince: null,
  }),
  (outboundState: TrackingState) => ({
    ...outboundState,
    session: null,
    dirtySince: null,
  }),
  { whitelist: ['tracking'] },
);

const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  whitelist: ['tracking'],
  transforms: [stripLiveSession],
  throttle: 3_000,
};

export type RootState = ReturnType<typeof rootReducer>;

// redux-persist's reducer typing is Partial-heavy; cast the base reducer on
// the way in and restore the concrete state type on the way out (standard
// workaround).
const persistedReducer = persistReducer(
  persistConfig,
  rootReducer as never,
) as unknown as Reducer<RootState, UnknownAction>;

export const store = configureStore({
  reducer: persistedReducer,
  middleware: getDefault =>
    getDefault({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistor = persistStore(store);

export type AppStore = typeof store;
export type AppDispatch = typeof store.dispatch;
