/**
 * App root: Redux + persistence + navigation + engine bootstrap.
 */
import React, { useEffect } from 'react';
import { AppState, StatusBar, StyleSheet, View, Text } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { store, persistor } from './src/app/store/store';
import RootNavigator from './src/app/navigation/RootNavigator';
import { trackingEngine } from './src/features/tracking/services/trackingEngine';
import { appStateChanged } from './src/features/tracking/store/trackingSlice';
import { sessionPersistence } from './src/features/tracking/services/sessionPersistence';
import type { AppStateLabel } from './src/features/tracking/types/gps';

function mapAppState(s: AppState['currentState']): AppStateLabel {
  return s === 'active' || s === 'background' || s === 'inactive' ? s : 'unknown';
}

export default function App() {
  useEffect(() => {
    // Give the engine access to the store.
    trackingEngine.attachStore(store);

    const sub = AppState.addEventListener('change', next => {
      const label = mapAppState(next);
      trackingEngine.setAppState(label);
      store.dispatch(appStateChanged({ appState: label, now: Date.now() }));
      // Flush pending persistence when going to background (requirement 8).
      if (label !== 'active') {
        const s = store.getState().tracking.session;
        if (s) {
          sessionPersistence.saveNow(s).catch(() => {});
        }
      }
    });

    return () => {
      sub.remove();
      trackingEngine.shutdown().catch(() => {});
    };
  }, []);

  return (
    <SafeAreaProvider>
      <Provider store={store}>
        <PersistGate
          loading={
            <View style={styles.gate}>
              <Text style={styles.gateText}>Loading…</Text>
            </View>
          }
          persistor={persistor}
        >
          <StatusBar barStyle="light-content" />
          <RootNavigator />
        </PersistGate>
      </Provider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  gate: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0d1117' },
  gateText: { color: '#9aa4b8', fontSize: 16 },
});
