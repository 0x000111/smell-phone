import UIKit
import React
import React_RCTAppDelegate
import ReactAppDependencyProvider

#if canImport(GoogleMapsBase)
import GoogleMapsBase
#endif

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
  var window: UIWindow?

  var reactNativeDelegate: ReactNativeDelegate?
  var reactNativeFactory: RCTReactNativeFactory?

  func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
  ) -> Bool {
    provideMapsKeyIfAvailable()

    let delegate = ReactNativeDelegate()
    let factory = RCTReactNativeFactory(delegate: delegate)
    delegate.dependencyProvider = RCTAppDependencyProvider()

    reactNativeDelegate = delegate
    reactNativeFactory = factory

    window = UIWindow(frame: UIScreen.main.bounds)

    factory.startReactNative(
      withModuleName: "VirtualWalkGpsPoc",
      in: window,
      launchOptions: launchOptions
    )

    return true
  }
}

class ReactNativeDelegate: RCTDefaultReactNativeFactoryDelegate {
  override func sourceURL(for bridge: RCTBridge) -> URL? {
    self.bundleURL()
  }

  override func bundleURL() -> URL? {
#if DEBUG
    RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: "index")
#else
    Bundle.main.url(forResource: "main", withExtension: "jsbundle")
#endif
  }
}

/// Reads GOOGLE_MAPS_API_KEY from Info.plist (added locally, never committed)
/// and passes it to the Google Maps SDK when the pod is linked.
private func provideMapsKeyIfAvailable() {
  guard let key = Bundle.main.object(forInfoDictionaryKey: "GOOGLE_MAPS_API_KEY") as? String,
        !key.isEmpty, key != "YOUR_GOOGLE_MAPS_API_KEY" else { return }
#if canImport(GoogleMapsBase)
  GMSServices.provideAPIKey(key)
#endif
}
