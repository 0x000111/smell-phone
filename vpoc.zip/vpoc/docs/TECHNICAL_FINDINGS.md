# TECHNICAL FINDINGS — GPS Tracking POC

Status: **code-complete and automated-verified; device matrix NOT yet
executed** (no physical-device results were available at build time). Do not
quote any "verified" claim below without a filled RESULTS_TEMPLATE.md run.

## 1. What this POC proves (build + automation evidence)

| Claim | Evidence |
|---|---|
| RN 0.85.3 (new architecture) compiles and bundles with react-native-geolocation-service 5.3.1, react-native-maps 1.27.2, voxel foreground-service 3.0.2 | `assembleDebug` BUILD SUCCESSFUL; debug APK produced (148 MB, all ABIs) |
| Legacy-arch modules work via interop layer on bridgeless RN 0.85 | compile + Metro bundle succeeded; runtime still to be confirmed on device |
| Filtering pipeline behaves deterministically | 41 Jest tests green: haversine, accuracy bands, pending buffer, gap anchor, pause/resume no-bridge, jump rejection, speed window, reducer transitions, persistence/restore, display simplification immutability |
| Incremental persistence is throttled (not per-callback) | unit-tested coalescing behaviour |
| App restart can recover an unfinished session's data | persistence round-trip unit-tested; UI restore banner implemented |

## 2. What this POC does NOT prove (requires device runs)

1. **Background/lockscreen continuity** — Android FGS + iOS `location`
   background mode are *configured*, but OEM battery killers and iOS
   suspension policies must be measured per device (matrix 4.2/4.3).
2. **Tracking after swipe-kill** — expected to STOP on both platforms; the
   POC deliberately distinguishes "keeps tracking in background" from
   "recovers data after restart". No claim of tracking-after-kill is made.
3. **Real GPS accuracy / distance error** — thresholds (25/50 m bands,
   30 s gap, 20 km/h) are starting values, not tuned. Run TEST_PLAN §2/§3/§5.
4. **Map performance at 500–10,000 points** — segmented polylines + DP
   simplification implemented; needs device FPS observation.
5. **Google Maps rendering with a real API key** — placeholder path verified
   (no crash without key); key wiring needs one real-key smoke test.

## 3. Key architectural decisions

- **Three data classes kept separate**: `rawPoints` (immutable device truth),
  `validatedPoints` (decisions + reasons), `displayPoints` (derived,
  simplifiable). Display simplification can never change mileage — enforced
  by design and unit test.
- **Conservative gap policy**: after a GPS gap or pause, the first trusted
  fix becomes a new anchor and is NOT bridged. This costs some true distance
  in exchange for never inventing mileage (underground, car rides, indoor
  starts).
- **Speed rule is a marker, not a killer**: excessive speed flags and
  rejects the segment only; `endSessionOnExcessiveSpeed` switch exists for
  the business to decide later.
- **All thresholds centralised** in `config/filterConfig.ts` +
  `config/samplingConfigs.ts`, editable at runtime via the Settings screen —
  tuning does not require a rebuild during field tests.
- **Distance accumulation lives in the reducer**, fed by validator results,
  so displayed, persisted, and exported numbers are always identical.

## 4. Platform differences observed (build-time)

| Topic | Android | iOS |
|---|---|---|
| Background location | foreground service + notification (`FOREGROUND_SERVICE_LOCATION` on API 34+); OEM-dependent survival | `UIBackgroundModes: location`; subscription continues while alive; no re-launch on exit |
| Permission UX | runtime FINE + BACKGROUND (separate dialogs); library surfaces Play-services errors as codes 4/5 | whenInUse request; "Always" needs an extra upgrade flow (not implemented — POC scope) |
| Provider info | `fused`/`gps`/`network` in position object | not exposed |
| Build friction | voxel lib hard-coded compileSdk 28 → patched via patch-package | pod install required (not run here: no Xcode on this machine) |

## 5. Known limitations / risks

- react-native-geolocation-service is unmaintained (last release 2022);
  interop works today but a production app should budget time to evaluate
  alternatives (e.g. `@react-native-community/geolocation` TurboModule or a
  custom Expo-location-style module) — **recommend a spike before committing**.
- Foreground service keeps the *process* alive; it does not guarantee the
  location client keeps sampling on aggressive ROMs — measure, then decide
  whether to instruct users to whitelist the app.
- No anti-cheat beyond physical plausibility; mocked-location flag is
  recorded (`mocked` field) but not acted upon.
- redux-persist + custom active-session key are intentionally redundant:
  the dedicated key survives even if persist flush ordering is interrupted.

## 6. Recommendations for the production plan

1. Run DEVICE_TEST_MATRIX on 2+ Android (one aggressive-OEM) and 2 iOS
   versions; fill RESULTS_TEMPLATE; then tune filterConfig thresholds.
2. If background-after-kill is a hard product requirement, neither platform
   supports it via this stack → plan for significant-location-change
   (iOS) / work-manager style scheduling (Android) as a *degraded* mode,
   or accept "resume on next open" semantics (recommended).
3. Choose the speed policy (20 km/h? segment-reject vs session-end?) —
   switches already exist; product decision only.
4. Decide Pause as a product feature; POC semantics: pause excludes time and
   distance, resume re-anchors.
5. Replace unmaintained geolocation lib with a maintained/TurboModule
   equivalent before production; the service wrapper isolates the swap to
   one file (`geolocationService.ts`).
6. Keep the accepted/pending/rejected taxonomy — it answers "why is this
   distance what it is" for support and anti-fraud review.

## 7. Open business decisions (from requirement §16)

Walk/Run only vs +Cycling; speed threshold value; excessive-speed action;
weak-signal auto-pause policy; Pause in product; pause-time counting;
restart policy (auto-resume vs user choice); cross-day sessions; acceptable
distance error; background/lockscreen support level.
