# TEST PLAN — GPS Tracking POC

Purpose: collect reproducible evidence for the Tech Lead to decide the
production GPS architecture. Every test below produces a row in
`RESULTS_TEMPLATE.md`.

> ⚠️ Synthetic coordinates are used ONLY for unit tests and map-performance
> stress. They must never be cited as GPS-accuracy evidence.

## 0. Automated checks (must pass before any device test)

```bash
corepack yarn typecheck && corepack yarn lint && corepack yarn test
```

## 1. Build & install

- `corepack yarn build:apk` → install `app-debug.apk` on a physical Android.
- iOS: `bundle exec pod install` in `ios/`, run from Xcode on a physical
  device (simulator GPS is fake).

## 2. Basic routes (Balanced config, debug overlay ON)

| # | Scenario | Procedure | Observe |
|---|---|---|---|
| 2.1 | Straight outdoor walk | Walk 500 m on open ground, Stop | validated distance vs known distance (±5% target) |
| 2.2 | Turned route | Walk a known 1 km loop with 4+ turns | track shape on map, segment count |
| 2.3 | Known 400 m track | One lap of a running track | error % (raw vs validated) |
| 2.4 | Stationary 15 min | Phone on a bench outdoors, Start, wait, Stop | drift distance (validated should stay ~0; raw will drift) |
| 2.5 | Walk–stop–walk | Walk 200 m, stand 3 min, walk 200 m | pause in distance during standing |
| 2.6 | Jog | 1 km jog | callback interval, accuracy band |
| 2.7 | Cycling | 2 km cycle | excessive-speed flags behaviour (default: marker only) |
| 2.8 | Walk → car → walk | 300 m walk, 5 min car ride, 300 m walk | car segment rejected; distances preserved |

## 3. GPS environments

| # | Scenario | Observe |
|---|---|---|
| 3.1 | Open sky | baseline accuracy P95 |
| 3.2 | Dense high-rises (urban canyon) | multipath drift, rejected count |
| 3.3 | Tree cover | accuracy degradation |
| 3.4 | Indoors near window | pending/rejected behaviour |
| 3.5 | Deep indoors | signal 'none', distance frozen |
| 3.6 | Underground / parking | gap detection, anchor on recovery |
| 3.7 | Indoor → outdoor walk | recovery time, first-fix-as-anchor |
| 3.8 | Toggle system location OFF then ON mid-session | error surfaced, session survives |
| 3.9 | Network off (airplane) with GPS ON | pure-GPS callbacks |
| 3.10 | Long weak-signal period then recovery | no distance bridged across gap |

## 4. App lifecycle (record per platform)

| # | Scenario | Expectation to VERIFY, not assume |
|---|---|---|
| 4.1 | Foreground | baseline |
| 4.2 | Background 10 min (Android FGS / iOS bg mode) | points keep arriving? count them |
| 4.3 | Screen locked 10 min | same |
| 4.4 | Switch to another app and back | resume latency |
| 4.5 | Incoming call during tracking | callbacks pause/resume |
| 4.6 | Swipe-kill app mid-session | tracking STOPS (documented); restart → data restored, distance preserved, re-anchor |
| 4.7 | OS reclaims process (low memory) | same as 4.6 |
| 4.8 | Restart app → restore banner | Resume keeps prior distance |

## 5. Sampling comparison

Run scenario 2.1 + 2.4 + 4.2 with each profile: **High / Balanced / Battery**.
Record: actual callback interval mean/P95, accuracy P95, validated distance
error %, stationary drift, battery % consumed over 30 min, device heat.

## 6. Map performance

Use the Diagnostics export or a synthetic breadcrumb (label it synthetic):
500 / 1,000 / 5,000 / 10,000 points. Record: FPS feel, Polyline update time,
memory warnings, when to enable display simplification.

## 7. Export & data integrity

- Export JSON mid-session and after Stop; verify it parses and contains raw +
  validated points + stats.
- Verify export never leaves the device (no network calls in the app).

## Deliverable per device run

One filled `RESULTS_TEMPLATE.md` row-set + exported JSON attached to the POC
report.
