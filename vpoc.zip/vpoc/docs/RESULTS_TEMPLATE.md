# RESULTS TEMPLATE

Copy one block per session run. Attach the exported JSON file name.

---

## Run ID: ____

| Field | Value |
|---|---|
| Date / time | |
| Device (model, OS version) | |
| Platform | Android / iOS |
| Sampling config | high / balanced / battery |
| Battery at start / end (%) | |
| Scenario (from TEST_PLAN) | e.g. 2.1 straight walk 500 m |
| Known/expected distance (m) | |
| App state coverage | foreground / background / locked (durations) |

### Metrics (from Diagnostics screen / exported JSON)

| Metric | Value |
|---|---|
| Raw points | |
| Accepted / pending / rejected | |
| Top rejection reasons | |
| Validated distance (m) | |
| Raw distance (m) | |
| Distance error % (vs known) | |
| Stationary drift (m, if applicable) | |
| Accuracy mean / P95 (m) | |
| Actual callback interval mean / P95 (s) | |
| GPS gap count / longest (s) | |
| Accepted / rejected segments | |
| Excessive-speed segments | |
| Points by app state (active/background) | |

### Observations (free text)

- Track shape vs reality:
- Map smoothness / lag:
- Notification / FGS behaviour:
- Anything surprising:

### Verdict for this run

⬜ Meets expectation / ⬜ Needs investigation / ⬜ Platform limitation
(see TECHNICAL_FINDINGS.md)

---

## Battery summary table (fill after config comparison)

| Config | 30 min walk: % battery | Heat | Callback interval P95 | Validated error % |
|---|---|---|---|---|
| high | | | | |
| balanced | | | | |
| battery | | | | |
