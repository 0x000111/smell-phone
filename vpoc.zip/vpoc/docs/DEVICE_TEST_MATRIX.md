# DEVICE TEST MATRIX

Checkboxes = to be executed on real hardware. Record each run in
RESULTS_TEMPLATE.md. Two devices minimum: one Android (API 31+ preferred,
note OEM battery policy) and one iOS (note iOS version).

Legend: ✅ done / ⬜ not yet / ➖ N/A

## Devices

| Device | OS | Notes |
|---|---|---|
| _fill in_ | Android __ / iOS __ | battery-optimisation whitelist: Y/N |

## Matrix (scenario × platform)

| Scenario | Android | iOS | Config(s) | Result link |
|---|---|---|---|---|
| 2.1 straight walk | ⬜ | ⬜ | B | |
| 2.2 turned route | ⬜ | ⬜ | B | |
| 2.3 known 400 m | ⬜ | ⬜ | B | |
| 2.4 stationary 15 min | ⬜ | ⬜ | H, B, T | |
| 2.5 walk-stop-walk | ⬜ | ⬜ | B | |
| 2.6 jog | ⬜ | ⬜ | B | |
| 2.7 cycling | ⬜ | ⬜ | B | |
| 2.8 walk-car-walk | ⬜ | ⬜ | B | |
| 3.1 open sky | ⬜ | ⬜ | all | |
| 3.2 urban canyon | ⬜ | ⬜ | B | |
| 3.3 tree cover | ⬜ | ⬜ | B | |
| 3.4 indoor window | ⬜ | ⬜ | B | |
| 3.5 deep indoor | ⬜ | ⬜ | B | |
| 3.6 underground | ⬜ | ⬜ | B | |
| 3.7 indoor→outdoor | ⬜ | ⬜ | B | |
| 3.8 location toggle off/on | ⬜ | ⬜ | B | |
| 3.9 airplane + GPS | ⬜ | ➖ (no GPS off radios) | B | |
| 3.10 long weak then recovery | ⬜ | ⬜ | B | |
| 4.1 foreground | ⬜ | ⬜ | all | |
| 4.2 background 10 min | ⬜ | ⬜ | all | |
| 4.3 lockscreen 10 min | ⬜ | ⬜ | all | |
| 4.4 app switch | ⬜ | ⬜ | B | |
| 4.5 incoming call | ⬜ | ⬜ | B | |
| 4.6 swipe-kill mid-session | ⬜ | ⬜ | B | |
| 4.7 OS reclaim | ⬜ | ⬜ | B | |
| 4.8 restart restore | ⬜ | ⬜ | B | |
| 5 sampling comparison | ⬜ | ⬜ | H/B/T | |
| 6 map perf 500/1k/5k/10k | ⬜ | ⬜ | B | |
| 7 JSON export integrity | ⬜ | ⬜ | B | |

## Specific things to judge per platform

### Android
- ⬜ Foreground-service notification appears and persists
- ⬜ `FOREGROUND_SERVICE_LOCATION` granted (Android 14+)
- ⬜ OEM battery manager does not kill FGS within 10 min (else document OEM)
- ⬜ provider field in exported JSON shows `fused`/`gps`/`network`
- ⬜ `ACCESS_BACKGROUND_LOCATION` flow (Play Store policy would need
  justification in production — note for Tech Lead)

### iOS
- ⬜ "Always allowed" vs "When in Use" permission dialogs behave as coded
- ⬜ Blue indicator / background location indicator while tracking
- ⬜ After swipe-kill: NO location updates resume (expected; confirm)
- ⬜ Restart restore banner appears with prior distance intact

## Pass criteria (POC acceptance, requirement 13.2)

1. Start/Pause/Resume/Stop work on real devices
2. Google map shows validated track live
3. Stationary test shows no significant fake mileage
4. Single outlier point does not spike distance
5. Weak/no signal pauses accumulation
6. Gap recovery does not bridge distance
7. Pause/Resume does not bridge distance
8. Pre-interruption validated distance survives restart
9. Background/lockscreen results reproducible and documented
10. Thresholds centralised
11. Local JSON export works
12. typecheck + lint + tests green
13. README lists limits and next steps
