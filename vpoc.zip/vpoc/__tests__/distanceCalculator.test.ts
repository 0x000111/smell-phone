/**
 * Distance + speed unit tests.
 * ⚠️ All coordinates are SYNTHETIC TEST DATA.
 */
import {
  distanceMeters,
  impliedSpeedMps,
  rawCumulativeDistance,
  windowAverageSpeedMps,
} from '../src/features/tracking/services/distanceCalculator';

describe('distanceCalculator (synthetic test data)', () => {
  test('haversine: ~111.32 km per degree latitude at equator', () => {
    const d = distanceMeters(
      { latitude: 0, longitude: 0 },
      { latitude: 1, longitude: 0 },
    );
    expect(d).toBeGreaterThan(111_000);
    expect(d).toBeLessThan(111_600);
  });

  test('zero movement yields zero distance', () => {
    const p = { latitude: 31.23, longitude: 121.47 };
    expect(distanceMeters(p, p)).toBe(0);
  });

  test('short distance is accurate to within 1 m for a 100 m step', () => {
    // 100 m north ≈ 0.000898 deg lat
    const a = { latitude: 0, longitude: 0 };
    const b = { latitude: 0.000898, longitude: 0 };
    const d = distanceMeters(a, b);
    expect(Math.abs(d - 100)).toBeLessThan(1.5);
  });

  test('raw cumulative distance sums consecutive segments', () => {
    const pts = [
      { latitude: 0, longitude: 0 },
      { latitude: 0.000898, longitude: 0 }, // ~100 m
      { latitude: 0.001796, longitude: 0 }, // ~200 m
    ];
    const total = rawCumulativeDistance(pts);
    expect(total).toBeGreaterThan(195);
    expect(total).toBeLessThan(205);
  });

  test('implied speed: 100 m over 10 s = 10 m/s', () => {
    const a = { latitude: 0, longitude: 0, timestamp: 1000 };
    const b = { latitude: 0.000898, longitude: 0, timestamp: 11_000 };
    expect(impliedSpeedMps(a, b)).toBeCloseTo(10, 0);
  });

  test('implied speed: non-positive dt returns 0 (duplicate timestamps)', () => {
    const a = { latitude: 0, longitude: 0, timestamp: 5000 };
    const b = { latitude: 0.000898, longitude: 0, timestamp: 5000 };
    expect(impliedSpeedMps(a, b)).toBe(0);
  });

  test('window average speed over a short window', () => {
    const pts = [
      { latitude: 0, longitude: 0, timestamp: 0 },
      { latitude: 0.000898, longitude: 0, timestamp: 5000 }, // 100 m / 5 s
      { latitude: 0.001796, longitude: 0, timestamp: 10_000 }, // 100 m / 5 s
    ];
    // Over last 10 s: ~200 m / 10 s = 20 m/s
    const avg = windowAverageSpeedMps(pts, 10_000);
    expect(avg).not.toBeNull();
    expect(avg!).toBeGreaterThan(19);
    expect(avg!).toBeLessThan(21);
  });
});
