/**
 * Session reducer state-machine tests (requirement 12.1: session reducer 状态转换).
 * ⚠️ Coordinates used are SYNTHETIC TEST DATA.
 */
import reducer, {
  startSession,
  sessionRunning,
  pointValidated,
  pauseSession,
  resumeSession,
  resumed,
  endSession,
  completeSession,
  restoreSession,
  markPersisted,
  rawPointReceived,
  setSignalLevel,
  setLastError,
} from '../src/features/tracking/store/trackingSlice';
import type { ValidatorResult } from '../src/features/tracking/services/pointValidator';
import type { RawGpsPoint } from '../src/features/tracking/types/gps';

function acceptedResult(distanceM: number): ValidatorResult {
  const raw: RawGpsPoint = {
    id: 'x',
    latitude: 0,
    longitude: 0,
    timestamp: 1000,
    accuracy: 10,
    altitude: null,
    altitudeAccuracy: null,
    speed: null,
    heading: null,
    appState: 'active',
    receivedAt: 1050,
  };
  return {
    point: { raw, decision: 'accepted', reason: null, segmentDistance: distanceM },
    addedDistance: true,
    distanceAddedM: distanceM,
    newAnchor: false,
    gapDetected: false,
    excessiveSpeedDetected: false,
  };
}

function startState() {
  let s = reducer(undefined, startSession({ sessionId: 's1', configId: 'balanced', now: 1000 }));
  s = reducer(s, sessionRunning({ now: 2000 }));
  return s;
}

describe('trackingSlice state machine', () => {
  test('start → starting → active_good_signal', () => {
    let s = reducer(undefined, startSession({ sessionId: 's1', configId: 'high', now: 1000 }));
    expect(s.session?.state).toBe('starting');
    s = reducer(s, sessionRunning({ now: 2000 }));
    expect(s.session?.state).toBe('active_good_signal');
    expect(s.session?.activeSince).toBe(2000);
  });

  test('accepted point adds validated distance; rejected does not', () => {
    let s = startState();
    s = reducer(
      s,
      pointValidated({
        result: { ...acceptedResult(12.5) },
        now: 3000,
      }),
    );
    expect(s.session?.validatedDistanceM).toBeCloseTo(12.5);
    expect(s.session?.stats.acceptedCount).toBe(1);

    const rejectedRaw: RawGpsPoint = { ...acceptedResult(0).point.raw, id: 'r' };
    s = reducer(
      s,
      pointValidated({
        result: {
          point: { raw: rejectedRaw, decision: 'rejected', reason: 'poor_accuracy' },
          addedDistance: false,
          distanceAddedM: 0,
          newAnchor: false,
          gapDetected: false,
          excessiveSpeedDetected: false,
        },
        now: 4000,
      }),
    );
    expect(s.session?.validatedDistanceM).toBeCloseTo(12.5); // unchanged
    expect(s.session?.stats.rejectedCount).toBe(1);
    expect(s.session?.stats.rejectionReasons.poor_accuracy).toBe(1);
  });

  test('pause stops active timing; resume restarts it', () => {
    let s = startState();
    s = reducer(s, pauseSession({ now: 5000 })); // active from 2000 → 3000ms banked
    expect(s.session?.state).toBe('paused');
    expect(s.session?.accumulatedActiveDurationMs).toBe(3000);
    expect(s.session?.activeSince).toBeNull();

    s = reducer(s, resumeSession({ now: 8000 }));
    expect(s.session?.state).toBe('resuming');
    expect(s.session?.pauseHistory[0].endedAt).toBe(8000);

    s = reducer(s, resumed({ now: 9000, level: 'good' }));
    expect(s.session?.state).toBe('active_good_signal');
    expect(s.session?.activeSince).toBe(9000);
  });

  test('weak signal keeps timer but flags state', () => {
    let s = startState();
    s = reducer(s, setSignalLevel({ level: 'weak', now: 3000 }));
    expect(s.session?.state).toBe('active_weak_signal');
    s = reducer(s, setSignalLevel({ level: 'good', now: 4000 }));
    expect(s.session?.state).toBe('active_good_signal');
  });

  test('stop → ending → completed moves session to history', () => {
    let s = startState();
    s = reducer(s, pointValidated({ result: acceptedResult(100), now: 3000 }));
    s = reducer(s, endSession({ now: 10_000 }));
    expect(s.session?.state).toBe('ending');
    s = reducer(s, completeSession({ now: 10_000 }));
    expect(s.session).toBeNull();
    expect(s.history).toHaveLength(1);
    expect(s.history[0].validatedDistanceM).toBeCloseTo(100);
    expect(s.history[0].activeDurationMs).toBe(8000);
  });

  test('raw point stats accumulate', () => {
    let s = startState();
    const mk = (t: number): RawGpsPoint => ({
      id: `p${t}`,
      latitude: 0,
      longitude: 0,
      timestamp: t,
      accuracy: 10,
      altitude: null,
      altitudeAccuracy: null,
      speed: null,
      heading: null,
      appState: 'active',
      receivedAt: t + 50,
    });
    s = reducer(s, rawPointReceived({ point: mk(3000) }));
    s = reducer(s, rawPointReceived({ point: mk(8000) }));
    expect(s.session?.stats.rawCount).toBe(2);
    expect(s.session?.stats.callbackIntervalsMs).toEqual([5000]);
  });

  test('restore keeps distance and marks session interrupted', () => {
    let s = startState();
    s = reducer(s, pointValidated({ result: acceptedResult(250), now: 3000 }));
    const saved = s.session!;
    let s2 = reducer(s, restoreSession({ session: saved }));
    expect(s2.session?.state).toBe('interrupted');
    expect(s2.session?.validatedDistanceM).toBeCloseTo(250); // distance preserved
  });

  test('restore clears activeSince so dead time is not counted as active', () => {
    let s = startState();
    // Simulate a session that was actively tracking when the process died:
    // activeSince is set, and accumulatedActiveDurationMs has time from a
    // previous pause segment.
    s = reducer(s, pointValidated({ result: acceptedResult(100), now: 2000 }));
    const mid = s.session!;
    expect(mid.activeSince).not.toBeNull();
    expect(mid.accumulatedActiveDurationMs).toBe(0);
    // Restore as if many hours later.
    const restored = reducer(s, restoreSession({ session: mid })).session!;
    expect(restored.state).toBe('interrupted');
    // The fix: activeSince must be null so a later endSession does NOT add
    // (now - activeSince) — which previously inflated "active" time by the
    // dead-process duration.
    expect(restored.activeSince).toBeNull();
    // Pre-kill accumulated time is preserved (still 0 in this scenario).
    expect(restored.accumulatedActiveDurationMs).toBe(0);
  });

  test('invalid transitions are ignored', () => {
    let s = startState();
    // completed → paused is not allowed
    s = reducer(s, endSession({ now: 5000 }));
    s = reducer(s, completeSession({ now: 5000 }));
    const before = s;
    s = reducer(s, pauseSession({ now: 6000 }));
    expect(s).toEqual(before);
  });

  test('markPersisted clears dirty flag', () => {
    let s = startState();
    s = reducer(s, markPersisted({ now: 5000 }));
    expect(s.dirtySince).toBeNull();
    expect(s.session?.lastPersistedAt).toBe(5000);
  });

  // Regression: on the real Xiaomi device, Stop right after Start (no fix
  // ever arrived, session still 'starting') silently did nothing.
  test('stop from starting state finalizes the session (regression)', () => {
    let s = reducer(undefined, startSession({ sessionId: 's1', configId: 'balanced', now: 1000 }));
    expect(s.session?.state).toBe('starting');
    s = reducer(s, endSession({ now: 2000 }));
    expect(s.session?.state).toBe('ending');
    s = reducer(s, completeSession({ now: 2000 }));
    expect(s.session).toBeNull();
    expect(s.history).toHaveLength(1);
  });

  test('raw distance accumulates incrementally (regression)', () => {
    let s = startState();
    const mk = (t: number, lon: number): RawGpsPoint => ({
      id: `p${t}`,
      latitude: 0,
      longitude: lon,
      timestamp: t,
      accuracy: 10,
      altitude: null,
      altitudeAccuracy: null,
      speed: null,
      heading: null,
      appState: 'active',
      receivedAt: t + 50,
    });
    s = reducer(s, rawPointReceived({ point: mk(3000, 0) }));
    s = reducer(s, rawPointReceived({ point: mk(8000, 0.000898) })); // ~100 m
    expect(s.session?.rawDistanceM).toBeGreaterThan(95);
    expect(s.session?.rawDistanceM).toBeLessThan(105);
  });

  test('setLastError stores and clears provider error hint', () => {
    let s = startState();
    s = reducer(s, setLastError({ message: 'Location services are OFF.' }));
    expect(s.session?.lastError).toBe('Location services are OFF.');
    s = reducer(s, setLastError({ message: null }));
    expect(s.session?.lastError).toBeNull();
  });
});
