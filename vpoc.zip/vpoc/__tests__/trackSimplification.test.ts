/**
 * Display-track simplification tests (requirement 12.1: display track 简化不改变
 * validated distance). ⚠️ SYNTHETIC TEST DATA.
 */
import {
  groupBySegment,
  simplifyForDisplay,
  toDisplayPoints,
} from '../src/features/tracking/utils/trackSimplification';
import type { ValidatedPoint } from '../src/features/tracking/types/gps';

function vp(
  i: number,
  lat: number,
  lon: number,
  decision: 'accepted' | 'pending' | 'rejected' = 'accepted',
): ValidatedPoint {
  return {
    raw: {
      id: `p${i}`,
      latitude: lat,
      longitude: lon,
      timestamp: i * 1000,
      accuracy: 10,
      altitude: null,
      altitudeAccuracy: null,
      speed: null,
      heading: null,
      appState: 'active',
      receivedAt: i * 1000 + 50,
    },
    decision,
    reason: decision === 'accepted' ? null : 'poor_accuracy',
  };
}

describe('trackSimplification (synthetic test data)', () => {
  test('toDisplayPoints keeps only accepted points', () => {
    const vps = [
      vp(0, 0, 0),
      vp(1, 0, 0.001, 'pending'),
      vp(2, 0, 0.002),
      vp(3, 0, 0.003, 'rejected'),
    ];
    const d = toDisplayPoints(vps, []);
    expect(d).toHaveLength(2);
    expect(d.every(p => p.kind === 'accepted')).toBe(true);
  });

  test('segment boundaries split the track (no line across a gap)', () => {
    const vps = [vp(0, 0, 0), vp(1, 0, 0.001), vp(2, 0, 0.002), vp(3, 0, 0.003)];
    // Boundary at index 2 (gap starts there).
    const d = toDisplayPoints(vps, [2]);
    const groups = groupBySegment(d);
    expect(groups).toHaveLength(2);
    expect(groups[0]).toHaveLength(2);
    expect(groups[1]).toHaveLength(2);
  });

  test('simplifyForDisplay reduces collinear points without changing endpoints', () => {
    const line = Array.from({ length: 1000 }, (_, i) => ({
      latitude: 0,
      longitude: i * 0.00001,
    }));
    const simplified = simplifyForDisplay(line, 0.00002);
    expect(simplified.length).toBeLessThan(line.length);
    expect(simplified[0]).toEqual(line[0]);
    expect(simplified[simplified.length - 1]).toEqual(line[line.length - 1]);
  });

  test('simplification does NOT mutate the validated points array', () => {
    const vps = Array.from({ length: 50 }, (_, i) => vp(i, 0, i * 0.00001));
    const before = JSON.stringify(vps);
    const d = toDisplayPoints(vps, []);
    simplifyForDisplay(
      d.map(p => ({ latitude: p.latitude, longitude: p.longitude })),
      0.00002,
    );
    expect(JSON.stringify(vps)).toBe(before);
  });
});
