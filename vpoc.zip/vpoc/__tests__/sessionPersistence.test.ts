/**
 * Persistence + restore tests (requirement 12.1).
 * ⚠️ All coordinates are SYNTHETIC TEST DATA.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SessionPersistence } from '../src/features/tracking/services/sessionPersistence';
import type { TrackingSession } from '../src/features/tracking/types/session';
import { createEmptyStats } from '../src/features/tracking/types/session';

function fakeSession(overrides: Partial<TrackingSession> = {}): TrackingSession {
  return {
    id: 'sess-1',
    state: 'active_good_signal',
    samplingConfigId: 'balanced',
    createdAt: 1000,
    startedAt: 1000,
    endedAt: null,
    accumulatedActiveDurationMs: 5000,
    activeSince: 6000,
    pauseHistory: [],
    rawPoints: [],
    validatedPoints: [],
    segmentBoundaries: [],
    validatedDistanceM: 123.4,
    rawDistanceM: 130,
    lastAcceptedPoint: null,
    lastAcceptedAt: null,
    signalLevel: 'good',
    lastFixAt: 6000,
    lastError: null,
    events: [],
    lastPersistedAt: null,
    stats: createEmptyStats(),
    ...overrides,
  };
}

describe('sessionPersistence (synthetic test data)', () => {
  beforeEach(async () => {
    await AsyncStorage.clear();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  test('saveNow writes and loadActive returns the session', async () => {
    const p = new SessionPersistence();
    const s = fakeSession();
    await p.saveNow(s);
    const { found, session } = await p.loadActive();
    expect(found).toBe(true);
    expect(session?.validatedDistanceM).toBe(123.4);
  });

  test('scheduleSave is throttled (not one write per callback)', async () => {
    const p = new SessionPersistence(5000);
    p.scheduleSave(fakeSession({ validatedDistanceM: 1 }));
    p.scheduleSave(fakeSession({ validatedDistanceM: 2 }));
    p.scheduleSave(fakeSession({ validatedDistanceM: 3 }));
    // Only the first call flushes immediately; the rest are coalesced.
    await jest.advanceTimersByTimeAsync(6000);
    const { session } = await p.loadActive();
    expect(session?.validatedDistanceM).toBe(3);
  });

  test('completed sessions are not restored', async () => {
    const p = new SessionPersistence();
    await p.saveNow(fakeSession({ state: 'completed' }));
    const { found } = await p.loadActive();
    expect(found).toBe(false);
  });

  test('clearActive removes the stored session', async () => {
    const p = new SessionPersistence();
    await p.saveNow(fakeSession());
    await p.clearActive();
    const { found } = await p.loadActive();
    expect(found).toBe(false);
  });

  test('exportSessionJson stores locally under a namespaced key', async () => {
    const p = new SessionPersistence();
    const key = await p.exportSessionJson(fakeSession());
    const stored = await AsyncStorage.getItem(key);
    expect(stored).toContain('sess-1');
  });
});
