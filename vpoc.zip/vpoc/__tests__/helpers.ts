/**
 * Shared test helpers.
 *
 * ⚠️ ALL COORDINATES PRODUCED HERE ARE SYNTHETIC TEST DATA. They are not real
 * GPS fixes and must never be used to draw any conclusion about real-device
 * GPS accuracy (requirement 12.1).
 */
import type { RawGpsPoint } from '../src/features/tracking/types/gps';
import type { AppStateLabel } from '../src/features/tracking/types/gps';

let n = 0;
export function raw(
  overrides: Partial<RawGpsPoint> & {
    latitude: number;
    longitude: number;
    timestamp: number;
  },
): RawGpsPoint {
  n += 1;
  const base = {
    accuracy: 10,
    altitude: null,
    altitudeAccuracy: null,
    speed: null,
    heading: null,
    appState: 'active' as AppStateLabel,
    // receivedAt slightly after device timestamp by default.
    receivedAt: overrides.timestamp + 50,
  };
  return { id: `t-${n}`, ...base, ...overrides };
}

/**
 * Walk `metres` east of an origin at ~lat 0 (1 deg lon ≈ 111.32 km at equator)
 * so distance maths is predictable in tests.
 */
export function eastBy(origin: { latitude: number; longitude: number }, metres: number) {
  const degPerMetre = 1 / 111_320;
  return { latitude: origin.latitude, longitude: origin.longitude + metres * degPerMetre };
}

/** Walk `metres` north of an origin. */
export function northBy(origin: { latitude: number; longitude: number }, metres: number) {
  const degPerMetre = 1 / 111_320;
  return { latitude: origin.latitude + metres * degPerMetre, longitude: origin.longitude };
}

export const SYNTHETIC_ORIGIN = { latitude: 0, longitude: 0 };
