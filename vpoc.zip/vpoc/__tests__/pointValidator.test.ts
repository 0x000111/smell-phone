/**
 * Point validator unit tests (requirement 12.1).
 * ⚠️ All coordinates are SYNTHETIC TEST DATA.
 */
import { PointValidator } from '../src/features/tracking/services/pointValidator';
import { DEFAULT_FILTER_CONFIG } from '../src/features/tracking/config/filterConfig';
import { raw, eastBy, northBy, SYNTHETIC_ORIGIN } from './helpers';

function makeValidator(overrides: Partial<typeof DEFAULT_FILTER_CONFIG> = {}) {
  return new PointValidator({ ...DEFAULT_FILTER_CONFIG, ...overrides });
}

describe('PointValidator (synthetic test data)', () => {
  test('first good point becomes anchor, adds no distance', () => {
    const v = makeValidator();
    const r = v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    expect(r.point.decision).toBe('accepted');
    expect(r.newAnchor).toBe(true);
    expect(r.addedDistance).toBe(false);
  });

  test('zero movement / duplicate position adds no distance', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    const r = v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 6000 }));
    expect(r.point.decision).toBe('accepted');
    // Below minMovementM → jitter, nothing accumulated.
    expect(r.addedDistance).toBe(false);
    expect(r.distanceAddedM).toBe(0);
    expect(r.point.reason).toBe('micro_movement');
  });

  test('stationary GPS jitter does not accumulate phantom distance', () => {
    // Regression: a phone left on a desk with the fused provider drifts a
    // few metres per fix; summing those deltas produced ~18 m of "walked"
    // distance in 15 minutes on the real device.
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000, accuracy: 8 }));
    // 12 fixes jittering within +/-2.5 m of the anchor, 5 s apart.
    const jitter = [
      [1.5, 0.8], [-2.2, 1.1], [0.9, -2.4], [-1.3, -1.6], [2.4, 0.4],
      [-0.7, 2.1], [1.8, -1.2], [-2.5, -0.5], [0.6, 2.3], [-1.9, 0.9],
      [2.1, -2.0], [-0.4, -1.1],
    ];
    let total = 0;
    jitter.forEach(([dx, dy], i) => {
      const p = eastBy(northBy(SYNTHETIC_ORIGIN, dy), dx);
      const r = v.validate(
        raw({ latitude: p.latitude, longitude: p.longitude, timestamp: 6000 + i * 5000, accuracy: 8 }),
      );
      total += r.distanceAddedM;
    });
    expect(total).toBe(0);
    // Anchor position is retained (not dragged along by jitter).
    const anchor = v.getAnchor()!;
    expect(anchor.latitude).toBe(SYNTHETIC_ORIGIN.latitude);
    expect(anchor.longitude).toBe(SYNTHETIC_ORIGIN.longitude);
  });

  test('real walking accumulates against the retained anchor', () => {
    // After jitter points, a genuine 12 m displacement must count in full
    // (measured from the original anchor, not from the last jitter fix).
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000, accuracy: 8 }));
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 2), timestamp: 6000, accuracy: 8 })); // jitter
    const walk = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 12), timestamp: 11_000, accuracy: 8 }));
    expect(walk.addedDistance).toBe(true);
    expect(walk.distanceAddedM).toBeGreaterThan(11);
    expect(walk.distanceAddedM).toBeLessThan(13);
  });

  test('duplicate timestamp is rejected', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 5000 }));
    const r = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 10), timestamp: 5000 }));
    expect(r.point.decision).toBe('rejected');
    expect(r.point.reason).toBe('duplicate_timestamp');
  });

  test('backwards timestamp is rejected', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 10_000 }));
    const r = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 5), timestamp: 9000 }));
    expect(r.point.decision).toBe('rejected');
    expect(r.point.reason).toBe('duplicate_timestamp');
  });

  test('invalid coordinates rejected', () => {
    const v = makeValidator();
    const r = v.validate(raw({ latitude: 123, longitude: 0, timestamp: 1000 }));
    expect(r.point.reason).toBe('invalid_coordinate');
    const r2 = v.validate(raw({ latitude: Number.NaN, longitude: 0, timestamp: 2000 }));
    expect(r2.point.reason).toBe('invalid_coordinate');
  });

  test('stale timestamp (device time far behind received time) rejected', () => {
    const v = makeValidator();
    const now = Date.now();
    const r = v.validate(
      raw({
        ...SYNTHETIC_ORIGIN,
        timestamp: now - 10 * 60_000, // 10 minutes old
        receivedAt: now,
      }),
    );
    expect(r.point.reason).toBe('stale_timestamp');
  });

  test('accuracy threshold: <=35 accepted, >50 rejected, 35-50 pending', () => {
    const v = makeValidator();
    const a = v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000, accuracy: 10 }));
    expect(a.point.decision).toBe('accepted');
    const b = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 5), timestamp: 6000, accuracy: 40 }));
    expect(b.point.decision).toBe('pending');
    const c = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 10), timestamp: 11_000, accuracy: 80 }));
    expect(c.point.decision).toBe('rejected');
    expect(c.point.reason).toBe('poor_accuracy');
  });

  test('single GPS jump point rejected, does not kill session', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 50), timestamp: 11_000 }));
    // Teleport 100 km in 1 s → impossible jump.
    const jump = v.validate(
      raw({ latitude: SYNTHETIC_ORIGIN.latitude, longitude: SYNTHETIC_ORIGIN.longitude + 1, timestamp: 12_000 }),
    );
    expect(jump.point.decision).toBe('rejected');
    expect(jump.point.reason).toBe('impossible_jump');
    // Session continues: next normal point still accepted.
    const next = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 100), timestamp: 17_000 }));
    expect(next.point.decision).toBe('accepted');
  });

  test('implied speed computed on accepted segment', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    const r = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 50), timestamp: 6000 }));
    expect(r.point.impliedSpeed).toBeCloseTo(10, 0); // 50 m / 5 s
  });

  test('excessive speed flagged after N consecutive points, segment rejected only', () => {
    const v = makeValidator({ speedFilterEnabled: true, excessiveSpeedConsecutivePoints: 3 });
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    let flagged = false;
    // 3 points at ~40 km/h (11.1 m/s) — over the 20 km/h threshold.
    for (let i = 1; i <= 3; i++) {
      const r = v.validate(
        raw({ ...eastBy(SYNTHETIC_ORIGIN, i * 55.5), timestamp: 1000 + i * 5000 }),
      );
      if (r.excessiveSpeedDetected) flagged = true;
    }
    expect(flagged).toBe(true);
    // Distance was still accumulated (POC default: marker only, session alive).
    expect(v.getAnchor()).not.toBeNull();
  });

  test('speed filtering can be switched off entirely', () => {
    const v = makeValidator({ speedFilterEnabled: false });
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    let flagged = false;
    for (let i = 1; i <= 5; i++) {
      const r = v.validate(
        raw({ ...eastBy(SYNTHETIC_ORIGIN, i * 200), timestamp: 1000 + i * 1000 }),
      );
      if (r.excessiveSpeedDetected) flagged = true;
    }
    expect(flagged).toBe(false);
  });

  test('pending point kept when trajectory confirms it', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000, accuracy: 10 }));
    const p = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 20), timestamp: 6000, accuracy: 40 }));
    expect(p.point.decision).toBe('pending');
    // Subsequent good point on the same line confirms the pending buffer.
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 40), timestamp: 11_000, accuracy: 8 }));
    expect(v.getPending().length).toBe(1); // still buffered as pending display
  });

  test('pending point dropped when later trajectory diverges', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000, accuracy: 10 }));
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 20), timestamp: 6000, accuracy: 40 }));
    // Accepted point far from the pending one (>30 s later so it is a gap
    // anchor, not an impossible jump) → pending dropped.
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 5000), timestamp: 61_000, accuracy: 5 }));
    expect(v.getPending().length).toBe(0);
  });

  test('GPS gap: first point after gap becomes anchor only, no distance bridged', () => {
    const v = makeValidator({ gpsGapThresholdMs: 30_000 });
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 100), timestamp: 6000 }));
    // 5-minute gap, then a fix 2 km away.
    const after = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 2100), timestamp: 306_000 }));
    expect(after.gapDetected).toBe(true);
    expect(after.newAnchor).toBe(true);
    expect(after.addedDistance).toBe(false); // no bridging across the gap
    expect(after.point.reason).toBe('gps_gap_anchor');
    // Next point after the gap DOES add distance.
    const next = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 2200), timestamp: 311_000 }));
    expect(next.addedDistance).toBe(true);
    expect(next.distanceAddedM).toBeGreaterThan(90);
    expect(next.distanceAddedM).toBeLessThan(110);
  });

  test('pause rejects points; resume re-anchors without bridging', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 100), timestamp: 6000 }));

    v.setPaused(true);
    const during = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 150), timestamp: 11_000 }));
    expect(during.point.decision).toBe('rejected');
    expect(during.point.reason).toBe('paused');

    v.setPaused(false);
    v.resetAnchor(); // engine does this on resume
    // First trusted point after resume: anchor only, no distance.
    const afterResume = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 900), timestamp: 61_000 }));
    expect(afterResume.newAnchor).toBe(true);
    expect(afterResume.addedDistance).toBe(false);
    // The 800 m displacement across the pause was NOT counted.
    const second = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 950), timestamp: 66_000 }));
    expect(second.addedDistance).toBe(true);
    expect(second.distanceAddedM).toBeGreaterThan(45);
    expect(second.distanceAddedM).toBeLessThan(55);
  });

  test('rejected point never adds validated distance', () => {
    const v = makeValidator();
    v.validate(raw({ ...SYNTHETIC_ORIGIN, timestamp: 1000 }));
    const rejected = v.validate(raw({ ...eastBy(SYNTHETIC_ORIGIN, 1000), timestamp: 1001, accuracy: 80 }));
    expect(rejected.point.decision).toBe('rejected');
    expect(rejected.addedDistance).toBe(false);
    expect(rejected.distanceAddedM).toBe(0);
  });
});
